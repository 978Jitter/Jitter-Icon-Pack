# JITTER icons – Kali XFCE

Install:  ./install.sh     Remove: ./uninstall.sh
Options:  --no-fill | --missing-only

What it is
- JITTER/          icon theme (1,278 colour + 445 symbolic icons; small/ variants for <=22px, scalable/ above, symbolic/ for panel + GTK widgets)
- tools/           everything is generated: jitlib.py (geometry), glyphs.py (112 glyphs, 16px grid), iconkit.py (plate/folder/document builders + KEYMAP),
                   build_icons.py (name tables), fill_missing.py (restyles icons of everything you have installed)

Design grammar (from the mockup): chamfered plates, diagonal hatch band, steel corner brackets, one red bracket per icon, red used only as the accent.
Falls back to Adwaita (symbolic, recolours to your GTK theme) then hicolor for anything not covered.

Tweak
- Add/rename a keyword->glyph rule: tools/iconkit.py KEYMAP, then run tools/fill_missing.py
- Replace the placeholder J (start-here, whisker menu): edit the "J" glyph in tools/glyphs.py
- Rebuild everything: python3 tools/build_icons.py JITTER   (needs only python3; preview.py needs numpy+Pillow)

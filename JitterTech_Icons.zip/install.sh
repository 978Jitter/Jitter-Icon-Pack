#!/usr/bin/env bash
# JITTER icon theme installer (Kali XFCE). Run as your normal user.
#   ./install.sh                full install + restyle every installed app's icon
#   ./install.sh --no-fill      install the shipped icons only
#   ./install.sh --missing-only only generate icons that nothing else provides
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/icons/JITTER"
FILL=1; FILLARGS=""
for a in "$@"; do case "$a" in --no-fill) FILL=0;; --missing-only) FILLARGS="--missing-only";; esac; done

echo "[1/4] installing theme -> $DEST"
mkdir -p "$HOME/.local/share/icons" "$HOME/.local/share/jitter-icons"
rm -rf "$DEST"; cp -r "$HERE/JITTER" "$DEST"
rm -rf "$HOME/.local/share/jitter-icons/tools"; cp -r "$HERE/tools" "$HOME/.local/share/jitter-icons/tools"

if [ "$FILL" = 1 ]; then
  echo "[2/4] scanning installed apps and generating matching icons"
  python3 "$HOME/.local/share/jitter-icons/tools/fill_missing.py" --theme-dir "$DEST" $FILLARGS
else
  echo "[2/4] skipped restyle (--no-fill)"
fi

echo "[3/4] building icon cache"
gtk-update-icon-cache -f -t "$DEST" 2>/dev/null || true

echo "[4/4] applying"
xfconf-query -c xsettings -p /Net/IconThemeName --create -t string -s JITTER
xfce4-panel -r >/dev/null 2>&1 &
( pgrep -x xfdesktop >/dev/null && xfdesktop --reload ) >/dev/null 2>&1 || true
echo
echo "Done. Root-run apps: sudo cp -r ~/.local/share/icons/JITTER /usr/share/icons/"
echo "After installing new tools later: python3 ~/.local/share/jitter-icons/tools/fill_missing.py && xfce4-panel -r"

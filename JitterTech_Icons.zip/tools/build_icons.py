#!/usr/bin/env python3
"""Builds the JITTER icon theme.   usage: build_icons.py <output_dir>"""
import os, sys, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from jitlib import *
from glyphs import G
from iconkit import *

OUT = sys.argv[1] if len(sys.argv) > 1 else "JITTER"
shutil.rmtree(OUT, ignore_errors=True)
T = Theme(OUT)

def P(g, **kw): return G[g](**kw)

# =============================================================== APPS (plates)
APPS = {
 "terminal":  ["utilities-terminal", "org.xfce.terminal", "xfce4-terminal", "terminal", "org.xfce.terminal-settings", "gnome-terminal", "xterm", "qterminal", "konsole"],
 "folder":    ["system-file-manager", "org.xfce.thunar", "thunar", "Thunar", "org.xfce.filemanager", "file-manager", "thunar-settings", "org.xfce.thunar-settings", "org.xfce.Thunar"],
 "globe":     ["web-browser", "internet-web-browser", "x-www-browser", "firefox-esr", "firefox", "chromium", "google-chrome", "epiphany", "browser", "applications-internet"],
 "edit":      ["accessories-text-editor", "org.xfce.mousepad", "mousepad", "text-editor", "gedit", "org.xfce.mousepad-settings"],
 "gear":      ["preferences-system", "org.xfce.settings.manager", "xfce4-settings-manager", "preferences-desktop", "org.xfce.settings.editor", "xfce4-settings-editor", "applications-system", "preferences-other", "preferences-desktop-default-applications", "org.xfce.settings.default-applications", "org.xfce.settings.helpers", "org.xfce.settings.accessibility", "preferences-desktop-accessibility", "org.xfce.settings.mime", "preferences-system-session", "org.xfce.session.settings", "xfce4-session-settings", "org.xfce.settings.workspaces", "preferences-system-windows", "org.xfce.xfwm4-tweaks-settings", "org.xfce.xfwm4-settings", "xfce4-notifyd", "org.xfce.notifyd.config", "preferences-desktop-notification", "xfce4-panel", "org.xfce.panel", "org.xfce.PanelProfiles", "org.xfce.panel.settings", "xfce4-panel-profiles", "org.xfce.settings.keyboard-shortcuts", "xfce4-settings"],
 "palette":   ["preferences-desktop-theme", "org.xfce.settings.appearance", "xfce4-appearance-settings", "preferences-desktop-color", "preferences-desktop-font", "preferences-desktop-wallpaper", "preferences-desktop-icons", "org.xfce.settings.color"],
 "monitor":   ["preferences-desktop-display", "org.xfce.settings.display", "xfce4-display-settings", "video-display", "preferences-system-display", "preferences-desktop-screensaver", "org.xfce.screensaver", "xfdesktop", "org.xfce.xfdesktop", "preferences-desktop-wallpaper-settings"],
 "keyboard":  ["preferences-desktop-keyboard", "org.xfce.settings.keyboard", "xfce4-keyboard-settings", "input-keyboard", "preferences-desktop-keyboard-shortcuts", "onboard"],
 "mouse":     ["preferences-desktop-peripherals", "org.xfce.settings.mouse", "xfce4-mouse-settings", "input-mouse", "input-touchpad", "preferences-desktop-mouse"],
 "ethernet":  ["preferences-system-network", "nm-device-wired", "network-wired", "network-workgroup", "network-wired-activated", "nm-connection-editor", "network-manager", "network-idle"],
 "wifi":      ["network-wireless", "nm-device-wireless", "network-wireless-connected", "network-wireless-activated", "preferences-system-network-wireless"],
 "power":     ["xfce4-power-manager-settings", "org.xfce.powermanager", "preferences-system-power", "system-shutdown", "xfce4-power-manager", "org.xfce.power-manager", "xfsm-shutdown-helper", "system-log-out", "system-reboot", "system-lock-screen"],
 "download":  ["system-software-install", "package-install", "org.xfce.PackageInstaller", "synaptic", "transmission", "qbittorrent"],
 "update":    ["system-software-update", "software-update-available", "update-manager", "software-update-urgent"],
 "pulse":     ["utilities-system-monitor", "org.xfce.taskmanager", "xfce4-taskmanager", "htop", "gnome-system-monitor", "xfce4-sensors", "org.xfce.sensors", "org.xfce.xfce4-sensors", "xfce4-systemload-plugin"],
 "calc":      ["accessories-calculator", "gnome-calculator", "galculator", "calculator", "org.gnome.Calculator", "org.xfce.calculator"],
 "shot":      ["applets-screenshooter", "org.xfce.screenshooter", "xfce4-screenshooter", "accessories-screenshooter", "applets-screenshooter-symbolic-no", "flameshot", "org.flameshot.Flameshot"],
 "search":    ["org.xfce.appfinder", "xfce4-appfinder", "system-search", "catfish", "org.xfce.catfish", "xfce4-appfinder-settings", "recoll"],
 "question":  ["help-browser", "help-about", "org.xfce.help", "xfce4-help", "yelp", "help-contents", "help-faq", "dialog-question-app"],
 "image":     ["org.xfce.ristretto", "ristretto", "eog", "org.gnome.eog", "image-viewer", "gimp", "org.gimp.GIMP", "shotwell", "multimedia-photo-viewer", "applications-graphics", "applications-images", "org.xfce.ristretto-settings"],
 "mail":      ["internet-mail", "evolution", "thunderbird", "mail-client", "org.xfce.mailreader", "mail-message", "email"],
 "video":     ["multimedia-video-player", "vlc", "mpv", "totem", "org.gnome.Totem", "applications-multimedia", "parole", "org.xfce.parole", "applications-video", "multimedia-player"],
 "music":     ["multimedia-audio-player", "audacious", "rhythmbox", "org.xfce.pulseaudio-plugin", "multimedia-volume-control", "pavucontrol", "preferences-desktop-sound", "audio-card", "applications-audio", "org.pulseaudio.pavucontrol", "xfce4-mixer", "org.xfce.mixer"],
 "archive":   ["file-roller", "org.gnome.FileRoller", "engrampa", "xarchiver", "org.xfce.xarchiver", "package-x-generic-app", "docker"],
 "code":      ["applications-development", "geany", "org.geany.Geany", "code", "vscode", "visual-studio-code", "text-x-source", "applications-ide", "python3", "python"],
 "filelines": ["applications-office", "libreoffice-writer", "evince", "org.gnome.Evince", "atril", "org.xfce.mousepad-doc", "document-viewer", "accessories-dictionary", "applications-accessories-docs"],
 "clock":     ["org.xfce.orage", "orage", "office-calendar", "xfce4-clock", "xfce4-datetime-plugin", "preferences-system-time", "appointment-new", "preferences-system-time-settings"],
 "camera":    ["camera-photo", "camera-web", "cheese", "org.gnome.Cheese", "webcam", "camera-video"],
 "disk":      ["drive-harddisk", "gparted", "org.gnome.DiskUtility", "gnome-disks", "disk-usage", "baobab", "org.gnome.baobab", "drive-harddisk-system", "drive-multidisk", "drive-harddisk-usb", "utilities-disk-usage", "org.xfce.gigolo", "gigolo"],
 "usb":       ["drive-removable-media", "drive-removable-media-usb", "media-removable", "usb-creator-gtk", "balena-etcher", "etcher", "drive-removable-media-usb-pendrive"],
 "optical":   ["drive-optical", "media-optical", "media-optical-cd-audio", "media-optical-dvd", "media-optical-data", "media-optical-audio", "media-cdrom", "media-optical-blank", "drive-cdrom", "drive-dvd", "media-cdrom-audio", "media-dvd", "media-cdrw"],
 "sdcard":    ["media-flash", "media-flash-sd-mmc", "media-flash-sd", "media-flash-memory-stick", "media-flash-sd-mini", "media-floppy"],
 "monitor2":  [],
 "laptop":    ["computer", "computer-laptop", "computer-symbolic-no", "pda", "computer-apple-ibook", "system-run-no"],
 "phone":     ["phone", "smartphone", "multimedia-player-apple-ipod-touch", "phone-apple-iphone", "phone-samsung-galaxy-s", "phone-google-nexus-one", "phone-htc-g1"],
 "rack":      ["network-server", "server-database", "network-server-symbolic-no", "applications-servers", "utilities-server", "network-server-database"],
 "netshare":  ["network-workgroup-app", "network-vpn", "network-vpn-acquiring", "org.xfce.gigolo-net", "network-transmit-receive-app", "folder-remote-app", "applications-network"],
 "shield":    ["security-high", "security-medium", "security-low", "security-high-no", "preferences-system-privacy", "preferences-desktop-security", "gnome-keyring", "seahorse", "applications-security", "firewall-config"],
 "lock":      ["changes-prevent", "dialog-password", "emblem-readonly-app", "preferences-system-lock", "xscreensaver", "light-locker", "light-locker-settings", "org.xfce.light-locker-settings", "system-lock-screen-app"],
 "user":      ["avatar-default", "user-available", "user-info", "system-users", "preferences-desktop-user", "stock_person", "user-identity", "contact-new", "preferences-system-users", "users", "org.xfce.users", "user-idle", "user-offline", "user-away", "user-busy", "avatar-default-symbolic-no"],
 "bolt":      ["applications-power", "xfce4-power-manager-bolt", "battery-full-charging-app"],
 "download2": [],
 "calendar":  [],
 "J":         ["start-here", "distributor-logo", "distributor-logo-kali", "xfce4-whiskermenu", "xfce4-whiskermenu-panel", "org.xfce.panel.whiskermenu", "whiskermenu", "xfce4-whiskermenu-plugin", "org.xfce.whiskermenu", "applications-all", "start-here-xfce", "xfce4-logo", "xfce-logo", "debian-logo", "gnome-logo-icon", "view-app-grid"],
 "kali":      ["kali-menu", "kali-menu-symbolic-no", "kali-logo", "kali-dragon", "kali-linux", "kali-hardware", "kali-extra-menu"],
 "dots":      ["applications-other", "applications-utilities", "applications-accessories", "org.xfce.panel.separator", "applications-extras", "kali-extra", "kali-extra-tools"],
 "gamepad":   [], "bug":[], 
}
# drop empty groups
APPS = {k: v for k, v in APPS.items() if v and k in G}

for glyph, names in APPS.items():
    for n in names:
        sc = plate(P(glyph), gscale=2.7 if glyph == "J" else None)
        sm = plate(P(glyph), small=True, gscale=3.1 if glyph == "J" else None)
        T.color("apps", n, sc, sm)

# =============================================================== KALI CATEGORIES (+ common aliases)
KALI = {
 "radar":     ["kali-information-gathering", "kali-info-gathering", "kali-01-info-gathering", "kali-01-information-gathering", "kali-recon", "kali-reconnaissance", "kali-osint"],
 "bug":       ["kali-vulnerability-analysis", "kali-02-vulnerability-analysis", "kali-vulnerability", "kali-vuln-analysis", "kali-vulnerability-assessment"],
 "globe":     ["kali-web-applications", "kali-03-web-applications", "kali-web-application-analysis", "kali-web", "kali-web-app-analysis"],
 "db":        ["kali-database-assessment", "kali-04-database-assessment", "kali-database"],
 "key":       ["kali-password-attacks", "kali-05-password-attacks", "kali-passwords", "kali-password-cracking"],
 "wifi":      ["kali-wireless-attacks", "kali-06-wireless-attacks", "kali-wireless"],
 "code":      ["kali-reverse-engineering", "kali-07-reverse-engineering", "kali-reversing"],
 "crosshair": ["kali-exploitation-tools", "kali-08-exploitation-tools", "kali-exploitation", "kali-exploit-tools"],
 "wave":      ["kali-sniffing-spoofing", "kali-09-sniffing-spoofing", "kali-sniffing", "kali-sniffing-and-spoofing"],
 "terminal":  ["kali-post-exploitation", "kali-10-post-exploitation", "kali-maintaining-access"],
 "search":    ["kali-forensics", "kali-11-forensics", "kali-digital-forensics"],
 "report":    ["kali-reporting", "kali-12-reporting", "kali-reporting-tools"],
 "mask":      ["kali-social-engineering", "kali-13-social-engineering", "kali-social-engineering-tools"],
 "chip":      ["kali-hardware-hacking", "kali-14-hardware-hacking", "kali-hardware"],
 "gear":      ["kali-system-services", "kali-15-system-services", "kali-services", "kali-sys-services"],
 "bolt":      ["kali-stress-testing", "kali-stress-test", "kali-dos", "kali-denial-of-service"],
 "dots":      ["kali-extra", "kali-extras", "kali-miscellaneous"],
 "kali":      ["kali-menu", "kali-linux"],
}
for glyph, names in KALI.items():
    for n in names:
        T.color("categories", n, plate(P(glyph)), plate(P(glyph), small=True))
        T.color("apps", n, plate(P(glyph)), plate(P(glyph), small=True))

# generic freedesktop categories
CATS = {"applications-internet": "globe", "applications-accessories": "dots", "applications-development": "code", "applications-games": "gamepad",
        "applications-graphics": "image", "applications-multimedia": "video", "applications-office": "filelines",
        "applications-science": "radar", "applications-system": "gear", "applications-utilities": "dots", "applications-other": "dots",
        "applications-engineering": "chip", "applications-education": "bookmark", "applications-security": "shield",
        "applications-network": "ethernet", "preferences-desktop-peripherals-cat": "mouse", "preferences-other": "gear",
        "applications-administration": "gear", "preferences-system": "gear", "preferences-desktop": "gear"}
for n, g in CATS.items():
    if g not in G: g = "dots"
    T.color("categories", n, plate(P(g)), plate(P(g), small=True))

# =============================================================== PLACES (folders)
def add_folder(names, glyph=None, open_=False, ctx="places", **kw):
    parts = P(glyph, **kw) if glyph else None
    for n in names:
        T.color(ctx, n, folder(parts, open_), folder(parts, open_, small=True))

add_folder(["folder", "inode-directory", "folder-visiting", "gnome-fs-directory", "folder-default"])
add_folder(["folder-open", "folder-drag-accept", "document-open-folder-no", "folder-opened"], open_=True)
add_folder(["user-home", "folder-home", "go-home-no"], "home")
add_folder(["user-desktop", "folder-desktop", "desktop"], "monitor")
add_folder(["folder-documents", "folder-document"], "filelines")
add_folder(["folder-download", "folder-downloads"], "download")
add_folder(["folder-music", "folder-audio"], "music")
add_folder(["folder-pictures", "folder-image", "folder-images"], "image")
add_folder(["folder-videos", "folder-video"], "video")
add_folder(["folder-templates", "folder-template"], "file")
add_folder(["folder-publicshare", "folder-public", "folder-share"], "users")
add_folder(["folder-remote", "folder-network", "network-server-folder"], "netshare")
add_folder(["folder-saved-search", "folder-search"], "search")
add_folder(["folder-recent", "document-open-recent-folder", "folder-recent-documents"], "clock")
add_folder(["folder-new", "folder-new-no"], "folderplus")
add_folder(["folder-bookmark", "user-bookmarks", "folder-favorites", "starred-folder"], "star")
add_folder(["folder-code", "folder-development", "folder-projects"], "code")
add_folder(["folder-encrypted", "folder-locked", "folder-private"], "lock")
add_folder(["folder-system", "folder-cog"], "gear")
add_folder(["folder-git", "folder-github"], "link")
add_folder(["folder-pcap", "folder-captures", "folder-wordlists", "folder-loot"], "wave")
add_folder(["user-trash", "trash-empty", "edit-delete-empty", "folder-trash", "user-trash-empty"], "trash")
add_folder(["user-trash-full", "trash-full", "folder-trash-full"], "trashfull")
add_folder(["network-workgroup-folder", "network-server-places", "network-workgroup-places", "network-vpn-places"], "netshare")
add_folder(["computer-places"], "laptop")

# =============================================================== MIMETYPES (documents)
MIME = [
 ("filelines", "gun",   ["text-x-generic", "text-plain", "text", "text-x-log", "text-x-readme", "text-x-copying", "text-x-changelog", "text-x-authors", "text-x-install", "text-x-makefile", "text-x-markdown", "text-markdown", "text-richtext", "text-rtf"]),
 ("file",      "gun",   ["application-octet-stream", "unknown", "application-x-generic", "text-x-preview", "application-x-zerosize", "application-x-core", "application-x-object", "application-x-trash", "text-x-generic-template", "application-x-fluid"]),
 ("shellcode", "burg",  ["text-x-script", "application-x-shellscript", "text-x-sh", "text-x-shellscript", "application-x-sh", "text-x-bash", "text-x-zsh", "application-x-csh", "text-x-batch", "application-x-powershell", "text-x-powershell"]),
 ("code",      "burg",  ["text-x-python", "text-x-python3", "text-x-csrc", "text-x-chdr", "text-x-c++src", "text-x-c++hdr", "text-x-java", "text-x-ruby", "text-x-perl", "text-x-php", "text-x-go", "text-x-rust", "text-x-lua", "text-x-javascript", "application-javascript", "text-javascript", "text-x-source", "text-css", "text-x-scss", "text-x-diff", "text-x-patch", "text-x-sql", "text-x-asm", "text-x-typescript", "text-x-makefile-src", "application-x-php", "application-x-ruby", "application-x-perl", "application-x-python", "text-x-tex", "text-x-cmake", "text-x-java-source", "text-x-pascal", "text-x-vala", "text-x-lisp", "text-x-haskell", "application-x-awk", "text-x-moc", "text-x-objcsrc", "text-x-csharp", "text-x-kotlin", "text-x-swift", "text-x-dockerfile", "text-x-ini", "text-x-toml", "text-x-config", "text-x-properties"]),
 ("globe",     "gun",   ["text-html", "text-xml", "application-xml", "application-xhtml+xml", "application-x-mswinurl", "application-x-desktop", "application-rss+xml", "application-atom+xml", "x-scheme-handler-http", "text-x-uri", "application-x-extension-html", "application-x-extension-htm", "application-x-extension-xhtml", "application-x-extension-xht", "application-x-url", "application-x-webarchive", "text-vnd.wap.wml"]),
 ("code",      "gun",   ["application-json", "application-x-yaml", "text-x-yaml", "application-yaml", "application-x-json", "text-json", "text-x-json", "application-ld+json", "application-x-ipynb+json", "application-toml", "text-x-xml"]),
 ("filelines", "crim",  ["application-pdf", "application-x-pdf", "application-postscript", "image-vnd.djvu", "application-x-dvi", "application-epub+zip", "application-x-mobipocket-ebook", "application-x-cbr", "application-x-cbz", "application-oxps", "application-vnd.ms-xpsdocument", "application-illustrator", "application-x-bzpdf", "application-x-gzpdf", "application-x-xzpdf", "image-x-eps", "application-x-ps", "application-eps", "application-x-gzpostscript", "application-x-ebook"]),
 ("filelines", "gun",   ["x-office-document", "application-msword", "application-vnd.openxmlformats-officedocument.wordprocessingml.document", "application-vnd.oasis.opendocument.text", "application-rtf", "application-vnd.ms-word", "application-vnd.oasis.opendocument.text-template", "x-office-address-book", "x-office-calendar", "text-calendar", "text-vcard", "application-vnd.sun.xml.writer", "application-x-abiword", "application-vnd.wordperfect", "application-x-docbook+xml", "x-office-document-template"]),
 ("grid",      "gun",   ["x-office-spreadsheet", "application-vnd.ms-excel", "application-vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application-vnd.oasis.opendocument.spreadsheet", "text-csv", "text-tab-separated-values", "application-x-gnumeric", "application-csv", "x-office-spreadsheet-template", "application-x-sc", "text-x-csv", "application-vnd.sun.xml.calc"]),
 ("monitor",   "gun",   ["x-office-presentation", "application-vnd.ms-powerpoint", "application-vnd.openxmlformats-officedocument.presentationml.presentation", "application-vnd.oasis.opendocument.presentation", "x-office-presentation-template", "application-vnd.sun.xml.impress"]),
 ("db",        "burg",  ["application-x-sqlite3", "application-vnd.sqlite3", "application-x-sqlite2", "application-sql", "application-vnd.oasis.opendocument.database", "application-x-sql", "application-x-dbf", "application-x-kexiproject-sqlite3", "application-x-mdb", "application-vnd.ms-access", "application-x-gdbm", "application-x-dbm", "application-x-berkeley-db", "application-x-lmdb", "application-x-leveldb", "application-x-realm"]),
 ("wave",      "red",   ["application-vnd.tcpdump.pcap", "application-x-pcapng", "application-pcap", "application-x-pcap", "application-vnd.tcpdump.pcapng", "application-x-snoop", "application-x-netmon", "application-x-wireshark", "application-x-cap", "application-x-har", "application-x-wireshark-capture", "application-x-etl", "application-x-erf", "application-x-nettl", "application-x-ngsniffer"]),
 ("archive",   "steel", ["package-x-generic", "application-x-archive", "application-zip", "application-x-zip", "application-x-zip-compressed", "application-x-tar", "application-x-compressed-tar", "application-gzip", "application-x-gzip", "application-x-bzip", "application-x-bzip2", "application-x-bzip-compressed-tar", "application-x-bzip2-compressed-tar", "application-x-xz", "application-x-xz-compressed-tar", "application-x-7z-compressed", "application-x-rar", "application-vnd.rar", "application-x-rar-compressed", "application-x-lzma", "application-x-lzma-compressed-tar", "application-x-lz4", "application-x-lzop", "application-x-zstd", "application-zstd", "application-x-zstd-compressed-tar", "application-x-cpio", "application-x-lha", "application-x-lzh", "application-x-arj", "application-x-ace", "application-x-compress", "application-x-compressed", "application-x-cab", "application-vnd.ms-cab-compressed", "application-x-stuffit", "application-x-zoo", "application-x-java-archive", "application-java-archive", "application-x-war", "application-x-ear", "application-x-apple-diskimage", "application-x-cd-image", "application-x-iso9660-image", "application-x-raw-disk-image", "application-x-virtualbox-vdi", "application-x-virtualbox-vmdk", "application-x-qemu-disk", "application-x-vmdk", "application-vnd.android.package-archive", "application-x-ar", "application-x-deb", "application-vnd.debian.binary-package", "application-x-rpm", "application-x-tarz", "application-x-source-rpm", "application-x-squashfs", "application-x-cd-image-no", "application-x-ova", "application-x-ovf", "application-x-vhd", "application-x-vhdx", "application-x-img", "application-x-bootable-iso", "application-x-gtar", "application-x-ustar", "application-x-pax", "application-x-shar", "application-x-tzo"]),
 ("shield",    "crim",  ["application-pgp-keys", "application-pgp-signature", "application-pgp-encrypted", "application-x-pem-file", "application-x-x509-ca-cert", "application-pkix-cert", "application-x-pkcs12", "application-pkcs7-mime", "application-pkcs7-signature", "application-pkcs8", "application-x-pkcs7-certificates", "application-x-ssh-key", "application-x-pgp-keys", "application-x-gnupg-keyring", "application-x-gpg-keyring", "application-x-keepass", "application-x-keepass2", "application-vnd.kde.kwallet", "application-x-openssh-key", "application-x-private-key", "application-x-public-key", "application-x-pkcs10", "application-x-cert", "application-x-crl", "application-pkix-crl", "application-pkcs10", "application-x-x509-user-cert", "application-x-x509-server-cert", "application-x-ssh-public-key", "application-x-ssh-private-key", "application-x-wallet", "application-x-ssl-cert", "application-x-pkcs8", "application-x-pkcs12-cert", "application-x-gnome-keyring", "application-x-veracrypt", "application-x-truecrypt", "application-x-luks", "application-x-hashcat", "application-x-hccapx", "application-x-john", "application-x-ntlm", "application-x-shadow", "application-x-htpasswd"]),
 ("gear",      "red",   ["application-x-executable", "application-x-sharedlib", "application-x-pie-executable", "application-x-elf", "application-x-ms-dos-executable", "application-x-msdownload", "application-x-dosexec", "application-x-ms-executable", "application-vnd.microsoft.portable-executable", "application-x-msi", "application-x-ms-installer", "application-x-java", "application-x-mach-binary", "application-x-pak", "application-x-appimage", "application-vnd.appimage", "application-x-flatpak", "application-vnd.flatpak", "application-vnd.snap", "application-x-bat", "application-x-ms-shortcut", "application-x-apple-bundle", "application-x-dll", "application-x-ms-dll", "application-x-ko", "application-x-kernel-module", "application-x-coff", "application-x-executable-no", "application-x-bin", "application-x-com", "application-x-ms-pe", "application-vnd.ms-cab-no", "application-x-ms-ne", "application-x-ms-wim", "application-x-sys", "application-x-vxd", "application-x-ocx", "application-x-scr", "application-x-ms-apps", "application-x-ms-msix", "application-vnd.ms-appx", "application-x-ms-xbap", "application-x-ms-application", "application-x-ms-manifest", "application-x-ms-reader", "application-x-gtk-builder-no", "application-x-sharedlib-no", "application-x-lib", "application-x-a", "application-x-ms-lib", "application-x-mo", "application-x-wine-extension-ini-no"]),
 ("image",     "gun",   ["image-x-generic", "image-png", "image-jpeg", "image-gif", "image-bmp", "image-tiff", "image-webp", "image-svg+xml", "image-svg+xml-compressed", "image-x-icon", "image-vnd.microsoft.icon", "image-x-xcf", "image-x-psd", "image-vnd.adobe.photoshop", "image-heif", "image-heic", "image-avif", "image-jxl", "image-x-portable-pixmap", "image-x-portable-bitmap", "image-x-portable-graymap", "image-x-pcx", "image-x-tga", "image-x-xbitmap", "image-x-xpixmap", "image-x-dds", "image-x-exr", "image-x-raw", "image-x-dcraw", "image-x-canon-cr2", "image-x-nikon-nef", "image-x-adobe-dng", "image-x-sony-arw", "image-x-sgi", "image-x-pict", "image-x-wmf", "image-x-emf", "image-x-eps-no", "image-x-compressed-xcf", "image-x-ico", "image-x-win-bitmap", "image-x-xwindowdump", "image-x-jng", "image-x-ms-bmp", "image-x-pcd", "image-x-sun-raster", "image-x-tiff-multipage", "image-x-quicktime", "image-x-apple-icns", "image-x-icns", "image-x-cursor", "image-x-xcursor", "image-x-gimp-gbr", "image-x-gimp-pat", "image-x-gimp-gih", "image-x-qoi", "image-x-fits", "image-x-hdr", "image-x-radiance", "image-fits", "application-x-krita", "application-x-gimp"]),
 ("music",     "gun",   ["audio-x-generic", "audio-mpeg", "audio-x-wav", "audio-x-flac", "audio-ogg", "audio-x-vorbis+ogg", "audio-x-opus+ogg", "audio-x-aac", "audio-mp4", "audio-x-m4a", "audio-x-ms-wma", "audio-midi", "audio-x-midi", "audio-x-mpegurl", "audio-x-scpls", "audio-x-aiff", "audio-x-matroska", "audio-webm", "audio-x-mod", "audio-x-it", "audio-x-xm", "audio-x-s3m", "audio-x-ape", "audio-x-wavpack", "audio-x-tta", "audio-x-musepack", "audio-basic", "audio-x-speex+ogg", "audio-vnd.rn-realaudio", "audio-x-pn-realaudio", "audio-ac3", "audio-x-ac3", "audio-x-dts", "audio-x-caf", "audio-3gpp", "audio-amr", "audio-x-amr", "audio-x-gsm", "audio-x-voc", "audio-x-sbc", "audio-x-sid", "audio-prs.sid", "audio-x-xmf", "audio-x-adpcm", "audio-x-ogg", "audio-x-oga", "audio-x-mp3", "audio-x-mpeg", "audio-x-mp2", "audio-x-mp1", "audio-x-mpg", "audio-x-mid", "audio-x-vorbis", "audio-x-opus", "audio-x-flac+ogg", "audio-x-ms-asx", "audio-x-gym", "audio-x-spc", "audio-x-nsf", "audio-x-vgm", "audio-x-gbs", "audio-x-hes", "audio-x-kss", "audio-x-sap", "audio-x-ay", "audio-x-psf"]),
 ("video",     "gun",   ["video-x-generic", "video-mp4", "video-mpeg", "video-x-matroska", "video-webm", "video-ogg", "video-x-msvideo", "video-quicktime", "video-x-flv", "video-x-ms-wmv", "video-x-theora+ogg", "video-vnd.mpegurl", "video-3gpp", "video-3gpp2", "video-x-ms-asf", "video-x-m4v", "video-mp2t", "video-x-ogm+ogg", "video-vnd.rn-realvideo", "video-x-avi", "video-avi", "video-msvideo", "video-x-mpeg", "video-x-mpeg2", "video-dv", "video-x-flic", "video-x-nsv", "video-x-anim", "video-x-ms-wm", "video-x-ms-wmx", "video-x-ms-wvx", "video-vnd.avi", "video-x-matroska-3d", "video-x-sgi-movie", "video-x-mng", "video-x-vob", "video-x-ogv", "video-ogv", "video-x-divx", "video-x-xvid", "video-x-mjpeg", "video-x-h264", "video-x-hevc", "video-x-vp8", "video-x-vp9", "video-x-av1", "video-x-prores", "video-x-dnxhd", "video-x-mxf", "video-mxf", "application-x-shockwave-flash", "application-vnd.rn-realmedia"]),
 ("terminal",  "burg",  ["application-x-terminal", "text-x-terminal", "application-x-sh-session", "text-x-typescript-session", "text-x-ttyrec", "application-x-asciicast", "application-x-script", "text-x-script-session"]),
 ("bookmark",  "gun",   ["application-x-bookmark", "application-x-mozilla-bookmarks", "text-x-bookmarks", "application-x-xbel", "application-x-opml+xml"]),
 ("star",      "gun",   ["application-x-favorites", "text-x-favorite"]),
 ("mail",      "gun",   ["message-rfc822", "application-mbox", "message-news", "application-x-mbox", "message-partial", "message-delivery-status", "message-disposition-notification", "message-external-body", "message-global", "application-ms-tnef", "application-vnd.ms-outlook", "application-x-msg", "application-x-pst", "application-x-ost", "message-x-gmail", "application-x-eml", "message-generic", "message-x-generic", "application-x-mail", "application-x-email", "text-x-mail", "text-x-email", "message-global-headers", "message-global-delivery-status", "message-global-disposition-notification", "message-x-rfc822", "application-x-emlx", "application-x-mboxrd", "application-x-maildir", "application-x-mh", "application-x-babyl", "application-x-mmdf"]),
 ("laptop",    "gun",   ["application-x-vm", "application-x-virtualbox-vbox", "application-x-vmware-vmx", "application-x-vagrant", "application-x-vagrantfile", "application-x-libvirt-xml", "application-x-qcow2", "application-x-ovf-no", "application-x-qemu-xml", "application-x-docker-image", "application-x-podman-image", "application-x-oci-image"]),
 ("download",  "gun",   ["application-x-bittorrent", "application-x-partial-download", "application-x-download", "application-x-xpinstall", "application-x-crdownload", "application-x-part", "application-x-aria2", "application-x-magnet", "x-scheme-handler-magnet", "application-x-metalink", "application-metalink4+xml", "application-metalink+xml", "application-x-jigdo", "application-x-nzb", "application-x-emule", "application-x-kad", "application-x-ed2k", "application-x-gnutella", "application-x-lime", "application-x-edonkey", "application-x-overnet"]),
 ("question",  "gun",   ["font-x-generic", "application-x-font-ttf", "application-x-font-otf", "font-ttf", "font-otf", "font-woff", "font-woff2", "application-font-woff", "application-vnd.ms-fontobject", "application-x-font-pcf", "application-x-font-type1", "application-x-font-bdf", "application-x-font-snf", "application-x-font-afm", "application-x-font-pfa", "application-x-font-pfb", "application-x-font-speedo", "application-x-font-linux-psf", "application-x-font-ttc", "application-x-font-sunos-news", "application-x-font-dos", "application-x-font-gf", "application-x-font-pf", "application-x-font-tex", "application-x-font-vfont", "application-x-font-type1-no", "font-collection", "font-sfnt", "application-x-font-sfnt", "application-x-font-opentype", "application-x-font-truetype", "application-x-font-woff", "application-x-font-woff2", "application-x-font-eot", "application-x-font-svg", "application-x-font-otc", "application-x-font-mm", "application-x-font-cff", "application-x-font-pfm", "application-x-font-tfm"]),
]
seen = set()
for glyph, band, names in MIME:
    parts = P(glyph)
    for n in names:
        if n in seen: continue
        seen.add(n)
        T.color("mimetypes", n, document(parts, band), document(parts, band, small=True))

# =============================================================== DEVICES that are not covered above
DEV = {"laptop": [], "keyboard": [], "disk": ["drive-harddisk-solidstate"], "usb": [], "mic": ["audio-input-microphone", "microphone", "audio-input-microphone-app"],
       "bluetooth": ["bluetooth", "bluetooth-active-app", "blueman", "blueman-manager", "preferences-bluetooth", "bluetooth-app"], "monitor": ["video-single-display", "video-display-app"],
       "ssd": ["drive-harddisk-ssd", "drive-harddisk-solid-state", "drive-harddisk-nvme"], "bell": ["notification-app", "xfce4-notifyd-app", "preferences-system-notifications", "notification-area-app"], "print": ["printer", "printer-network", "printer-remote", "document-print-app", "printer-default", "printer-printing", "preferences-printer", "system-config-printer", "printer-error", "printer-warning", "printer-paused"],
       "volume": ["audio-speakers", "audio-volume-high-app", "audio-headphones", "audio-headset", "multimedia-volume-control-app", "audio-volume-high", "audio-volume-medium", "audio-volume-low", "audio-volume-muted", "audio-card-app"]}
for g, names in DEV.items():
    for n in names:
        add_plate(T, "devices" if not n.startswith("preferences") and "app" not in n else "apps", n, g)

# =============================================================== STATUS (dialogs etc.)
def dialog(glyph, danger=False):
    return plate(P(glyph), danger=danger, gscale=2.3), plate(P(glyph), small=True, danger=danger, gscale=2.6)
for n, g, dg in [("dialog-information", "sign_info", False), ("dialog-warning", "sign_warn", False), ("dialog-error", "sign_err", True),
                 ("dialog-question", "sign_q", False), ("dialog-password-status", "lock", False), ("emblem-important", "sign_warn", False),
                 ("dialog-information-app", "sign_info", False), ("dialog-warning-app", "sign_warn", False), ("dialog-error-app", "sign_err", True),
                 ("process-stop-app", "sign_err", True), ("emblem-default", "check", False), ("emblem-ok", "check", False), ("emblem-system", "gear", False)]:
    large, small = dialog(g, dg)
    T.color("status" if "app" not in n else "apps", n, large, small)

# network / battery / weather like status icons in color (panel uses symbolic; these cover other apps)
for n, g, kw in [("network-offline", "wifi", dict(level=0, off=True)), ("network-error", "sign_err", {}), ("network-wired-disconnected", "ethernet", {}),
                 ("battery", "battery", dict(level=100)), ("battery-full", "battery", dict(level=100)), ("battery-empty", "battery", dict(level=5)),
                 ("battery-caution", "battery", dict(level=15)), ("battery-low", "battery", dict(level=25)), ("battery-good", "battery", dict(level=65)),
                 ("battery-full-charging", "battery", dict(level=100, charging=True)), ("ac-adapter", "bolt", {}),
                 ("software-update-available-status", "update", {})]:
    add_plate(T, "status" if n != "battery" else "devices", n, g, **kw)

# =============================================================== SYMBOLIC
def S(ctx, name, parts): T.sym(ctx, name, parts)

ACT = {
 "list-add": "plus", "list-remove": "minus", "edit-delete": "trash", "edit-copy": "copy", "edit-cut": "cut", "edit-paste": "paste",
 "edit-undo": "undo", "edit-redo": "redo", "edit-find": "search", "system-search": "search", "edit-clear": "x", "edit-clear-all": "x",
 "edit-select-all": "grid", "edit-find-replace": "search", "document-new": "fileplus", "document-open": "folderopen", "document-save": "save",
 "document-save-as": "save", "document-print": "print", "document-properties": "gear", "document-edit": "edit", "edit": "edit", "document-open-recent": "clock",
 "document-revert": "undo", "document-send": "upload", "document-print-preview": "print", "folder-new": "folderplus", "bookmark-new": "bookmark", "list-add-user": "user",
 "go-up": ("arrow", dict(d=270)), "go-down": ("arrow", dict(d=90)), "go-next": ("arrow", dict(d=0)), "go-previous": ("arrow", dict(d=180)),
 "go-top": ("arrow", dict(d=270)), "go-bottom": ("arrow", dict(d=90)), "go-first": ("arrow", dict(d=180)), "go-last": ("arrow", dict(d=0)), "go-home": "home",
 "go-jump": ("arrow", dict(d=0)), "pan-down": ("pan", dict(d=90)), "pan-up": ("pan", dict(d=270)), "pan-start": ("pan", dict(d=180)), "pan-end": ("pan", dict(d=0)),
 "view-refresh": "refresh", "view-fullscreen": "brackets", "view-restore": "restore", "view-more": "dots", "view-more-horizontal": "dots", "view-list": "list", "view-grid": "grid",
 "view-list-symbolic-no": "list", "view-sort-ascending": ("arrow", dict(d=270)), "view-sort-descending": ("arrow", dict(d=90)), "view-continuous": "menu", "view-paged": "file",
 "open-menu": "menu", "view-app-grid": "grid", "window-close": "x", "window-minimize": "minus", "window-maximize": "brackets", "window-restore": "restore",
 "application-exit": "logout", "system-log-out": "logout", "system-shutdown": "power", "system-reboot": "refresh", "system-lock-screen": "lock",
 "system-suspend": "moon", "system-hibernate": "moon", "zoom-in": "zoomin", "zoom-out": "zoomout", "zoom-fit-best": "brackets", "zoom-original": "restore",
 "media-playback-start": "play", "media-playback-pause": "pause", "media-playback-stop": "stop", "media-skip-forward": "skip", "media-skip-backward": "skip",
 "media-seek-forward": "seek", "media-seek-backward": "seek", "media-record": "record", "media-eject": "eject", "media-playlist-repeat": "refresh", "media-playlist-shuffle": "wave",
 "object-select": "check", "emblem-ok": "check", "process-stop": "x", "preferences-system": "gear", "emblem-system": "gear", "applications-system": "gear",
 "send-to": "upload", "mail-send": "upload", "mail-reply-sender": "undo", "mail-forward": "redo", "mail-unread": "mail", "mail-read": "mail", "mail-message-new": "mail",
 "insert-link": "link", "insert-image": "image", "edit-find-symbolic-no": "search", "emblem-favorite": "star", "starred": "star", "non-starred": "star", "bookmark": "bookmark",
 "list-remove-all": "x", "tab-new": "plus", "window-new": "plus", "pan-down-no": "pan", "help-about": "info", "help-browser": "question", "dialog-question": "question",
 "dialog-information": "info", "dialog-warning": "sign_warn", "dialog-error": "sign_err", "dialog-password": "lock", "changes-prevent": "lock", "changes-allow": "unlock",
 "document-edit-symbolic-no": "edit", "emblem-important": "bang", "task-due": "clock", "appointment-soon": "clock", "alarm": "clock", "preferences-system-time": "clock",
 "content-loading": "refresh", "find-location": "crosshair", "mark-location": "crosshair", "find-location-no": "search", "system-run": "terminal", "utilities-terminal": "terminal",
 "download": "download", "go-down-no": "download", "folder-download": "download", "folder-upload": "upload", "network-transmit-receive": ("arrow", dict(d=90)), "network-transmit": ("arrow", dict(d=270)), "network-receive": ("arrow", dict(d=90)),
 "software-update-available": "update", "software-update-urgent": "sign_warn", "system-software-install": "download", "system-software-update": "update",
 "view-private": "lock", "view-reveal": "search", "view-conceal": "lock", "edit-reset": "undo", "format-text-bold": "edit", "color-select": "palette", "preferences-color": "palette",
 "dialog-ok": "check", "dialog-cancel": "x", "dialog-close": "x", "dialog-apply": "check", "user-trash": "trash", "user-trash-full": "trashfull", "edit-delete-no": "trash",
}
for n, v in ACT.items():
    g, kw = (v, {}) if isinstance(v, str) else v
    if g not in G: continue
    parts = P(g, **kw)
    if n in ("media-skip-backward", "media-seek-backward"): parts = parts_mirror(parts)
    S("actions", n, parts)

PLACES = {"folder": "folder", "folder-open": "folderopen", "inode-directory": "folder", "user-home": "home", "user-desktop": "monitor", "folder-documents": "filelines",
          "folder-download": "download", "folder-music": "music", "folder-pictures": "image", "folder-videos": "video", "folder-templates": "file", "folder-publicshare": "users",
          "folder-remote": "netshare", "network-workgroup": "netshare", "network-server": "rack", "user-bookmarks": "star", "folder-saved-search": "search", "user-trash": "trash",
          "folder-recent": "clock", "starred-location": "star", "network-wired": "ethernet", "mark-location": "crosshair", "folder-new": "folderplus", "folder-drag-accept": "folderopen",
          "folder-visiting": "folder", "user-trash-full": "trashfull", "computer": "laptop", "folder-development": "code"}
for n, g in PLACES.items(): S("places", n, P(g))

DEVICES = {"drive-harddisk": "disk", "drive-harddisk-solidstate": "ssd", "drive-harddisk-system": "disk", "drive-removable-media": "usb", "drive-optical": "optical",
           "media-optical": "optical", "media-flash": "sdcard", "media-floppy": "save", "media-removable": "usb", "computer": "laptop", "computer-laptop": "laptop",
           "video-display": "monitor", "input-keyboard": "keyboard", "input-mouse": "mouse", "input-touchpad": "mouse", "input-gaming": "crosshair", "audio-card": "volume",
           "audio-headphones": "volume", "audio-headset": "volume", "audio-speakers": "volume", "audio-input-microphone": "mic", "camera-photo": "camera", "camera-web": "camera",
           "camera-video": "video", "phone": "phone", "printer": "print", "printer-network": "print", "network-wired": "ethernet", "network-wireless": "wifi", "bluetooth": "bluetooth",
           "multimedia-player": "music", "scanner": "shot", "uninterruptible-power-supply": "bolt", "pda": "phone", "network-server": "rack", "media-tape": "optical", "modem": "ethernet",
           "thunderbolt": "bolt", "usb-c": "usb", "sd-card": "sdcard", "drive-multidisk": "disk", "drive-harddisk-usb": "usb", "drive-removable-media-usb": "usb",
           "media-optical-cd-audio": "optical", "media-optical-dvd": "optical", "media-optical-blu-ray": "optical", "drive-cdrom": "optical"}
for n, g in DEVICES.items(): S("devices", n, P(g))

MIMESYM = {"text-x-generic": "filelines", "application-x-executable": "gear", "image-x-generic": "image", "audio-x-generic": "music", "video-x-generic": "video",
           "package-x-generic": "archive", "x-office-document": "filelines", "x-office-spreadsheet": "grid", "x-office-presentation": "monitor", "font-x-generic": "question",
           "text-html": "globe", "text-x-script": "shellcode", "application-pdf": "filelines", "text-x-python": "code", "application-x-sharedlib": "gear", "application-x-archive": "archive",
           "x-office-address-book": "users", "x-office-calendar": "clock", "application-x-sqlite3": "db", "application-x-generic": "file", "unknown": "file", "application-octet-stream": "file",
           "text-x-source": "code", "inode-directory": "folder", "application-vnd.tcpdump.pcap": "wave", "application-pgp-keys": "key", "application-x-pem-file": "key"}
for n, g in MIMESYM.items(): S("mimetypes", n, P(g))

CATSYM = {"applications-internet": "globe", "applications-accessories": "dots", "applications-development": "code", "applications-graphics": "image", "applications-multimedia": "video",
          "applications-office": "filelines", "applications-system": "gear", "applications-utilities": "dots", "applications-other": "dots", "applications-science": "radar",
          "applications-engineering": "chip", "applications-games": "crosshair", "applications-security": "shield", "preferences-other": "gear", "preferences-desktop": "gear",
          "preferences-system": "gear", "preferences-desktop-theme": "palette", "preferences-desktop-display": "monitor", "preferences-desktop-keyboard": "keyboard",
          "preferences-desktop-peripherals": "mouse", "preferences-system-network": "ethernet", "preferences-system-power": "power", "preferences-desktop-wallpaper": "image",
          "preferences-desktop-font": "edit", "preferences-desktop-sound": "volume", "preferences-system-users": "user", "preferences-system-privacy": "lock",
          "preferences-system-bluetooth": "bluetooth", "preferences-system-notifications": "bell", "preferences-desktop-accessibility": "user", "preferences-system-session": "power"}
for n, g in CATSYM.items():
    S("categories", n, P(g)); S("apps", n, P(g))

# ---- status: audio / mic / battery / network / notifications
for lvl, nm in [(0, "muted"), (1, "low"), (2, "medium"), (3, "high")]:
    S("status", f"audio-volume-{nm}", P("volume", level=lvl))
S("status", "audio-volume-overamplified", P("volume", level=3))
for lvl, nm in [(0, "muted"), (1, "low"), (2, "medium"), (3, "high")]:
    S("status", f"microphone-sensitivity-{nm}", P("mic", muted=(lvl == 0)))
S("status", "microphone-disabled", P("mic", muted=True)); S("status", "audio-input-microphone-muted", P("mic", muted=True))
for lvl in range(0, 101, 10):
    S("status", f"battery-level-{lvl}", P("battery", level=lvl))
    S("status", f"battery-level-{lvl}-charging", P("battery", level=lvl, charging=True))
S("status", "battery-level-100-charged", P("battery", level=100, charging=True))
for n, lvl, ch in [("battery-full", 100, False), ("battery-good", 65, False), ("battery-low", 30, False), ("battery-caution", 15, False), ("battery-empty", 3, False),
                   ("battery-full-charging", 100, True), ("battery-good-charging", 65, True), ("battery-low-charging", 30, True), ("battery-caution-charging", 15, True),
                   ("battery-empty-charging", 3, True), ("battery-full-charged", 100, True), ("battery-missing", 0, False), ("battery", 80, False), ("battery-empty-charged", 3, False)]:
    S("status", n, P("battery", level=lvl, charging=ch))
S("status", "ac-adapter", P("bolt")); S("status", "system-shutdown", P("power"))
for n, lvl in [("none", 1), ("weak", 2), ("ok", 3), ("good", 4), ("excellent", 4)]:
    S("status", f"network-wireless-signal-{n}", P("wifi", level=lvl))
for n, kw in [("network-wireless", dict(level=4)), ("network-wireless-connected", dict(level=4)), ("network-wireless-acquiring", dict(level=2)), ("network-wireless-offline", dict(level=1, off=True)),
              ("network-wireless-disabled", dict(level=1, off=True)), ("network-wireless-no-route", dict(level=1, off=True)), ("network-wireless-hotspot", dict(level=4)),
              ("network-wireless-encrypted", dict(level=4)), ("network-cellular-signal-excellent", dict(level=4)), ("network-cellular-signal-good", dict(level=3)),
              ("network-cellular-signal-ok", dict(level=3)), ("network-cellular-signal-weak", dict(level=2)), ("network-cellular-signal-none", dict(level=1)), ("network-cellular-offline", dict(level=1, off=True))]:
    S("status", n, P("wifi", **kw))
for n in ("network-wired", "network-wired-activated", "network-wired-acquiring", "network-idle", "network-transmit", "network-receive", "network-transmit-receive", "network-wired-no-route", "network-vpn", "network-vpn-acquiring"):
    S("status", n, P("ethernet") if "vpn" not in n else P("shield"))
S("status", "network-wired-disconnected", P("ethernet") + [A(flat(bar(2, 14, 14, 2, 1.6, 0.3)))])
S("status", "network-offline", P("wifi", level=1, off=True)); S("status", "network-error", P("sign_err")); S("status", "network-server", P("rack"))
S("status", "network-workgroup", P("netshare"))
for n, g in [("notification", "bell"), ("notification-disabled", "bell"), ("notification-new", "bell"), ("preferences-system-notifications", "bell"), ("bluetooth-active", "bluetooth"),
             ("bluetooth-disabled", "bluetooth"), ("bluetooth-paired", "bluetooth"), ("bluetooth-offline", "bluetooth"), ("bluetooth-connected", "bluetooth"),
             ("dialog-information", "info"), ("dialog-warning", "sign_warn"), ("dialog-error", "sign_err"), ("dialog-question", "question"), ("dialog-password", "lock"),
             ("security-high", "shield"), ("security-medium", "shield"), ("security-low", "sign_warn"), ("changes-prevent", "lock"), ("changes-allow", "unlock"),
             ("user-available", "user"), ("user-away", "user"), ("user-idle", "user"), ("user-offline", "user"), ("user-busy", "user"), ("avatar-default", "user"),
             ("emblem-default", "check"), ("object-select", "check"), ("starred", "star"), ("non-starred", "star"), ("software-update-available", "update"),
             ("software-update-urgent", "sign_warn"), ("sync-synchronizing", "refresh"), ("sync-error", "sign_err"), ("task-due", "clock"), ("appointment-missed", "clock"),
             ("weather-clear", "sign_info"), ("dialog-password-no", "lock"), ("media-record", "record"), ("media-playback-start", "play"), ("media-playback-pause", "pause"),
             ("media-playback-stop", "stop"), ("process-working", "refresh"), ("image-loading", "refresh"), ("image-missing", "image"), ("dialog-ok", "check"),
             ("dialog-cancel", "x"), ("camera-video", "video"), ("microphone-sensitivity-medium-no", "mic"), ("display-brightness", "sign_info"), ("night-light", "moon"),
             ("airplane-mode", "wifi"), ("keyboard-brightness", "keyboard"), ("system-run", "terminal")]:
    S("status", n, P(g, **({"level": 1, "off": True} if n == "airplane-mode" else {})))

# =============================================================== write
T.index()
n_color = len(T.names["color"]); n_sym = len(T.names["symbolic"])
print(f"built {n_color} colour + {n_sym} symbolic icons -> {OUT}")

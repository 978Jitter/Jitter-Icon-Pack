#!/usr/bin/env python3
"""Generate JITTER-style icons for every icon name your installed apps ask for.

  fill_missing.py                 restyle ALL Icon= names found in .desktop/.directory files (uniform look)
  fill_missing.py --missing-only  only names no theme in the inherit chain can already provide
  fill_missing.py --dry-run       show what would be generated

Names are mapped to a glyph by keyword (nmap -> radar, wireshark -> wave, hashcat -> key ...);
anything unknown gets a stable pick from a neutral tool-glyph set. Edit KEYMAP in iconkit.py to taste.
"""
import os, sys, re, glob, argparse, subprocess, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from iconkit import Theme, plate, guess_glyph
from glyphs import G

ap = argparse.ArgumentParser()
ap.add_argument("--theme-dir", default=os.path.expanduser("~/.local/share/icons/JITTER"))
ap.add_argument("--missing-only", action="store_true")
ap.add_argument("--dry-run", action="store_true")
ap.add_argument("--extra-dir", action="append", default=[], help="extra dir of .desktop/.directory files")
a = ap.parse_args()

home = os.path.expanduser("~")
src_dirs = ["/usr/share/applications", "/usr/local/share/applications", home + "/.local/share/applications",
            "/usr/share/desktop-directories", home + "/.local/share/desktop-directories",
            "/var/lib/flatpak/exports/share/applications", "/var/lib/snapd/desktop/applications"] + a.extra_dir

wanted = collections.OrderedDict()   # name -> ctx
for d in src_dirs:
    for f in glob.glob(os.path.join(d, "**", "*.desktop"), recursive=True) + glob.glob(os.path.join(d, "**", "*.directory"), recursive=True):
        ctx = "categories" if f.endswith(".directory") else "apps"
        try:
            for line in open(f, errors="ignore"):
                m = re.match(r"^Icon=(.+?)\s*$", line)
                if m:
                    n = m.group(1)
                    if n.startswith("/") or re.search(r"\.(png|svg|xpm|svgz|ico)$", n): continue
                    wanted.setdefault(n, ctx); break
        except OSError: pass

def names_in(root):
    s = set()
    for dp, _, fs in os.walk(root):
        for f in fs:
            b, e = os.path.splitext(f)
            if e in (".svg", ".png", ".xpm", ".svgz"): s.add(b)
    return s

have = names_in(a.theme_dir) if os.path.isdir(a.theme_dir) else set()
chain = set()
if a.missing_only:
    for r in ("/usr/share/icons/Adwaita", "/usr/share/icons/hicolor", "/usr/share/pixmaps", home + "/.local/share/icons/hicolor"):
        if os.path.isdir(r): chain |= names_in(r)

todo = [(n, c) for n, c in wanted.items() if n not in have and not (a.missing_only and n in chain)]
print(f"{len(wanted)} icon names requested by installed apps; {len(todo)} to generate")
if a.dry_run:
    for n, c in todo[:200]: print(f"  {n:40s} -> {guess_glyph(n)}")
    sys.exit(0)

T = Theme(a.theme_dir)
dist = collections.Counter()
for n, ctx in todo:
    g = guess_glyph(n); dist[g] += 1
    T.color(ctx, n, plate(G[g]()), plate(G[g](), small=True))
    if ctx == "categories":                         # menu code looks categories up in apps too
        T.color("apps", n, plate(G[g]()), plate(G[g](), small=True))
print("glyph usage:", ", ".join(f"{k}:{v}" for k, v in dist.most_common()))
subprocess.call(["gtk-update-icon-cache", "-f", "-t", a.theme_dir], stderr=subprocess.DEVNULL)
print("done. run: xfce4-panel -r")

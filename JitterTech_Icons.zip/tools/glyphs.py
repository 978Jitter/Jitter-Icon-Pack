"""JITTER glyph library. Every glyph lives on a 16x16 grid and returns parts [(role, subpaths)].
roles: m = main (silver)  a = accent (red)  d = dim (steel)
"""
import math
from jitlib import *

G = {}
def glyph(*names):
    def deco(fn):
        for n in names: G[n] = fn
        return fn
    return deco

# ------------------------------------------------------------- basics
@glyph("plus")
def _(): return [M(box(7, 2.5, 2, 11), box(2.5, 7, 11, 2))]

@glyph("minus")
def _(): return [M(box(3, 7, 10, 2))]

@glyph("x")
def _(): return [M(bar(3.8, 3.8, 12.2, 12.2, 2, 0.4), bar(3.8, 12.2, 12.2, 3.8, 2, 0.4))]

@glyph("check")
def _(): return [M(pline([(3, 8.5), (6.5, 12), (13, 4.8)], 2.1))]

@glyph("arrow")
def _(d=0):  # d = rotation: 0 right, 90 down, 180 left, 270 up
    return parts_rot([M(bar(2, 8, 12.5, 8, 2, 0), pline([(8.5, 4), (12.5, 8), (8.5, 12)], 2))], d)

@glyph("chevron")
def _(d=90):  # 90 = pointing down
    return parts_rot([M(pline([(5.5, 3.5), (10, 8), (5.5, 12.5)], 2))], d - 0)

@glyph("pan")
def _(d=90):
    return parts_rot([M(pline([(4.5, 3), (9.5, 8), (4.5, 13)], 1.8))], d - 0)

@glyph("menu")
def _(): return [M(box(2, 3, 12, 2), box(2, 7, 12, 2), box(2, 11, 12, 2))]

@glyph("dots")
def _(): return [M(box(2, 6.8, 2.4, 2.4), box(6.8, 6.8, 2.4, 2.4), box(11.6, 6.8, 2.4, 2.4))]

@glyph("dotsv")
def _(): return parts_rot(G["dots"](), 90)

@glyph("list")
def _(): return [M(box(5, 3, 9, 2), box(5, 7, 9, 2), box(5, 11, 9, 2)), A(box(2, 3, 2, 2), box(2, 7, 2, 2), box(2, 11, 2, 2))]

@glyph("grid")
def _(): return [M(box(2, 2, 5, 5), box(9, 2, 5, 5), box(2, 9, 5, 5), box(9, 9, 5, 5))]

@glyph("brackets")  # HUD corner brackets = fullscreen
def _(inward=False):
    L = 4.5
    pts = [[(2, 2 + L), (2, 2), (2 + L, 2)], [(14 - L, 2), (14, 2), (14, 2 + L)],
           [(14, 14 - L), (14, 14), (14 - L, 14)], [(2 + L, 14), (2, 14), (2, 14 - L)]]
    return [M(*[pline(p, 1.8, 0.9) for p in pts])]

@glyph("restore")
def _():
    L = 4
    pts = [[(5 - 0, 2), (5, 5), (2, 5)], [(11, 2), (11, 5), (14, 5)], [(14, 11), (11, 11), (11, 14)], [(2, 11), (5, 11), (5, 14)]]
    return [M(*[pline(p, 1.8, 0.9) for p in pts])]

# ------------------------------------------------------------- files & folders
@glyph("file")
def _():
    return [M(polyhole([(3, 1.5), (9.5, 1.5), (13, 5), (13, 14.5), (3, 14.5)], [(5, 3.5), (8.7, 3.5), (11, 5.8), (11, 12.5), (5, 12.5)])),
            D(poly([(9.5, 1.5), (13, 5), (9.5, 5)]))]

@glyph("filelines")
def _():
    return [M(polyhole([(3, 1.5), (9.5, 1.5), (13, 5), (13, 14.5), (3, 14.5)], [(5, 3.5), (8.7, 3.5), (11, 5.8), (11, 12.5), (5, 12.5)]),
             box(6, 7, 4, 1.3), box(6, 9.6, 4, 1.3))]

@glyph("folder")
def _():
    return [M(polyhole([(1.5, 3), (6.2, 3), (8, 5), (14.5, 5), (14.5, 13.5), (1.5, 13.5)],
                       [(3.4, 6.8), (12.6, 6.8), (12.6, 11.7), (3.4, 11.7)]))]

@glyph("home")
def _():
    return [M(pline([(1.5, 8), (8, 2), (14.5, 8)], 2), box(3.5, 8, 2, 6), box(10.5, 8, 2, 6), box(3.5, 12.5, 9, 1.5)),
            A(box(7, 10, 2, 4))]

@glyph("trash")
def _():
    return [M(box(2.5, 3.5, 11, 2), box(6, 1.8, 4, 1.7),
              polyhole([(3.8, 6.8), (12.2, 6.8), (11.5, 14.5), (4.5, 14.5)], [(5.6, 8.4), (10.4, 8.4), (10, 12.8), (6, 12.8)])),
            D(box(7.3, 8.8, 1.4, 3.4))]

@glyph("trashfull")
def _():
    return [M(box(2.5, 3.5, 11, 2), box(6, 1.8, 4, 1.7),
              polyhole([(3.8, 6.8), (12.2, 6.8), (11.5, 14.5), (4.5, 14.5)], [(5.6, 8.4), (10.4, 8.4), (10, 12.8), (6, 12.8)])),
            A(box(6.2, 9, 3.6, 3.4))]

@glyph("search")
def _():
    return [M(ring(6.6, 6.6, 5, 2.9), bar(10.2, 10.2, 14, 14, 2.4, 0.2))]

@glyph("zoomin")
def _(): return G["search"]() + [A(box(5.8, 4.2, 1.6, 4.8), box(4.2, 5.8, 4.8, 1.6))]

@glyph("zoomout")
def _(): return G["search"]() + [A(box(4.2, 5.8, 4.8, 1.6))]

@glyph("gear")
def _():
    teeth = []
    for k in range(8):
        teeth += rot([box(6.9, 0.8, 2.2, 3.2)], 45 * k)
    return [M(ring(8, 8, 5, 2.3), teeth)]

@glyph("power")
def _():
    v = ngon_pts(8, 8.6, 5.6)
    order = [6, 7, 0, 1, 2, 3, 4, 5]
    return [M(pline([v[i] for i in order], 2, 0.9)), A(bar(8, 1.5, 8, 8, 2, 0))]

@glyph("refresh")
def _():
    v = ngon_pts(8, 8, 5.2)
    order = [6, 7, 0, 1, 2, 3, 4]
    return [M(pline([v[i] for i in order], 2, 0.4), tri((2.2, 3.3), (7.2, 2.3), (4.2, 7.2)))]

@glyph("moon")
def _():
    return [M(pline([(3, 7), (9, 7), (3, 14), (9, 14)], 1.8, 0.2)), A(pline([(9.5, 1.5), (13.5, 1.5), (9.5, 6), (13.5, 6)], 1.5, 0.2))]

@glyph("lock")
def _():
    return [M(frame(4.5, 1.5, 7, 7, 2, 2), polyhole([(3, 7), (13, 7), (13, 14.5), (3, 14.5)], [(7.4, 9.2), (8.6, 9.2), (8.6, 12), (7.4, 12)]))]

@glyph("unlock")
def _():
    return [M(pline([(4.5, 7), (4.5, 3.5), (6, 2), (9.5, 2), (11, 3.5), (11, 4.5)], 2, 0.5),
              polyhole([(3, 7), (13, 7), (13, 14.5), (3, 14.5)], [(7.4, 9.2), (8.6, 9.2), (8.6, 12), (7.4, 12)]))]

@glyph("copy")
def _():
    return [M(frame(5.5, 5.5, 8, 8.5, 1.8, 1), pline([(3, 10.5), (3, 2), (9.5, 2)], 1.8, 0.9))]

@glyph("cut")
def _():
    return [M(bar(5, 1.8, 11, 10.5, 1.8, 0), bar(11, 1.8, 5, 10.5, 1.8, 0), ring(4.6, 12.3, 2.6, 1.1), ring(11.4, 12.3, 2.6, 1.1))]

@glyph("paste")
def _():
    return [M(frame(2.5, 3, 11, 11.5, 1.8, 1.2), box(5.5, 1.3, 5, 3.2, 1))]

@glyph("undo")
def _():
    return [M(pline([(5, 8), (10, 8), (13, 10.5), (13, 13)], 2, 0.3), tri((2, 8), (6.6, 3.6), (6.6, 12.4)))]

@glyph("redo")
def _(): return parts_mirror(G["undo"]())

@glyph("save")
def _():
    return [M(frame(1.8, 1.8, 12.4, 12.4, 1.8, 2.5), box(5, 1.8, 6, 4.4), box(4.8, 9, 6.4, 5.2)), A(box(8.8, 2.8, 1.3, 2.2))]

@glyph("print")
def _():
    return [M(frame(1.5, 5.5, 13, 6, 1.8, 1), frame(4, 1.5, 8, 4.5, 1.6, 0), box(4, 10, 8, 4.5)), A(box(11.2, 7.3, 1.4, 1.2))]

@glyph("edit")
def _():
    return [M(bar(5, 10.5, 11.5, 4, 3.2, 0), tri((2.2, 13.8), (3.4, 9.7), (6.3, 12.6)), box(11, 1.8, 3, 3, 0) if False else [])]

@glyph("star")
def _():
    pts = []
    for i in range(10):
        r = 6.8 if i % 2 == 0 else 3.0
        a = math.radians(-90 + 36 * i)
        pts.append((8 + r * math.cos(a), 8.4 + r * math.sin(a)))
    return [M(poly(pts))]

@glyph("bookmark")
def _():
    return [M(polyhole([(3.5, 1.5), (12.5, 1.5), (12.5, 14.5), (8, 10.8), (3.5, 14.5)], [(5.4, 3.4), (10.6, 3.4), (10.6, 11.1), (8, 8.9), (5.4, 11.1)]))]

@glyph("download")
def _():
    return [M(pline([(4, 6.5), (8, 10.5), (12, 6.5)], 2), bar(8, 1.8, 8, 9, 2, 0), box(2.5, 12.8, 11, 1.8))]

@glyph("upload")
def _(): return parts_rot(G["download"](), 180)

@glyph("clock")
def _():
    return [M(ring(8, 8, 6.5, 4.6)), A(bar(8, 8, 8, 4.3, 1.6, 0.4), bar(8, 8, 10.6, 9.6, 1.6, 0.4))]

@glyph("question")
def _():
    return [M(box(5, 2, 6, 2), polyhole([(10, 2), (12.2, 2), (12.2, 8), (7.2, 8), (7.2, 10.2), (10, 10.2), (10, 6)], [(10, 4), (10, 6), (10, 4)]) if False else box(10, 3.5, 2.2, 3.5),
              box(7.2, 6.2, 4.8, 2), box(7.2, 8, 2, 2)), A(box(7.2, 11.5, 2, 2))]

@glyph("info")
def _(): return [M(box(7, 6.5, 2, 6.5), box(6, 12, 4, 1.5), box(6, 6.5, 2, 1.3)), A(box(7, 3, 2, 2))]

@glyph("bang")
def _(): return [M(box(7, 3, 2, 6.5)), A(box(7, 11, 2, 2))]

# ------------------------------------------------------------- signs
@glyph("sign_info")
def _(): return [M(ring(8, 8, 7, 5.2)), *[(r, s) for r, s in G["info"]() ]]

@glyph("sign_warn")
def _():
    return [M(polyhole([(8, 1.2), (15, 14), (1, 14)], [(8, 5), (12.6, 12.4), (3.4, 12.4)])), A(box(7, 7, 2, 2.8), box(7, 10.6, 2, 1.6))]

@glyph("sign_err")
def _(): return [M(ring(8, 8, 7, 5.2)), A(bar(5.3, 5.3, 10.7, 10.7, 1.8, 0.2), bar(5.3, 10.7, 10.7, 5.3, 1.8, 0.2))]

@glyph("sign_q")
def _(): return [M(ring(8, 8, 7, 5.2)), *[(r, xf(s, 0.62, 0.62, 3.05, 3.05)) for r, s in G["question"]()]]

# ------------------------------------------------------------- media
@glyph("play")
def _(): return [M(poly([(4, 2.2), (13, 7), (13, 9), (4, 13.8)]))]

@glyph("pause")
def _(): return [M(box(3.5, 2.5, 3.2, 11), box(9.3, 2.5, 3.2, 11))]

@glyph("stop")
def _(): return [M(box(3, 3, 10, 10))]

@glyph("skip")
def _(): return [M(poly([(3, 3), (10.5, 7), (10.5, 9), (3, 13)]), box(11.3, 3, 2.2, 10))]

@glyph("seek")
def _(): return [M(poly([(1.5, 3.5), (7.5, 7), (7.5, 9), (1.5, 12.5)]), poly([(8.5, 3.5), (14.5, 7), (14.5, 9), (8.5, 12.5)]))]

@glyph("record")
def _(): return [A(ngon(8, 8, 5.8))]

@glyph("eject")
def _(): return [M(poly([(8, 2.2), (14, 9), (2, 9)]), box(2, 11, 12, 2.4))]

@glyph("volume")
def _(level=3):
    sp = poly([(1.5, 6), (4, 6), (7.5, 2.8), (7.5, 13.2), (4, 10), (1.5, 10)])
    parts = [M(sp)]
    waves = [[(9.6, 6.2), (10.8, 8), (9.6, 9.8)], [(11.4, 4.3), (13.1, 8), (11.4, 11.7)], [(13, 2.4), (15.3, 8), (13, 13.6)]]
    for i in range(min(level, 3)):
        parts.append(M(pline(waves[i], 1.5, 0.5)))
    if level == 0:
        parts.append(M(bar(10, 5.5, 14.8, 10.5, 1.7, 0), bar(10, 10.5, 14.8, 5.5, 1.7, 0)))
    return parts

@glyph("mic")
def _(muted=False):
    p = [M(frame(5.5, 1.5, 5, 7.5, 1.8, 2), pline([(3.5, 7.5), (3.5, 9), (8, 12.5), (12.5, 9), (12.5, 7.5)], 1.5, 0), box(7.3, 12, 1.4, 2.5), box(5, 14, 6, 1.3))]
    if muted: p.append(A(bar(2.5, 13.5, 13.5, 2.5, 1.7, 0.3)))
    return p

@glyph("bell")
def _():
    return [M(polyhole([(8, 1.5), (11, 3), (11.8, 8), (13.8, 11.2), (2.2, 11.2), (4.2, 8), (5, 3)],
                       [(8, 3.5), (9.6, 4.4), (10, 8.5), (11, 9.4), (5, 9.4), (6, 8.5), (6.4, 4.4)]), box(6.2, 12.2, 3.6, 1.8, 0.5))]

@glyph("battery")
def _(level=100, charging=False):
    p = [M(frame(1, 4, 12.5, 8, 1.6, 1.2), box(13.5, 6.3, 1.6, 3.4))]
    w = max(0.0, 8.4 * level / 100)
    if level > 0:
        p.append(A(box(3, 6, w, 4)) if level <= 20 else M(box(3, 6, w, 4)))
    if charging:
        p.append(("w", flat(poly([(8.8, 3.2), (5, 8.4), (7.7, 8.4), (6.8, 12.8), (10.8, 7.2), (8, 7.2)]))))
    return p

@glyph("wifi")
def _(level=4, off=False):
    parts = [M(box(6.9, 12, 2.2, 2.2))]
    arcs = [(2.4, 8.7), (4.8, 5.5), (7.0, 2.3)]
    for i, (w, y) in enumerate(arcs):
        on = i < level - 1 if level < 4 else True
        pts = [(8 - w, y + w), (8, y), (8 + w, y + w)]
        parts.append((M if on else D)(pline(pts, 1.5, 0.3)))
    if off: parts.append(A(bar(2.5, 13.5, 13.5, 2, 1.7, 0.3)))
    return parts

@glyph("ethernet")
def _():
    return [M(frame(2, 2, 12, 8, 1.8, 1), box(7.1, 10, 1.8, 2.5), box(2, 12.3, 12, 1.8)), D(box(4.3, 4.2, 1.2, 2.2), box(7.4, 4.2, 1.2, 2.2), box(10.5, 4.2, 1.2, 2.2))]

@glyph("bluetooth")
def _(): return [M(pline([(4.5, 5), (11, 10.8), (8, 14), (8, 2), (11, 5.2), (4.5, 11)], 1.6, 0.2))]

@glyph("user")
def _():
    return [M(ngon(8, 5, 3), poly([(2.5, 14.5), (2.5, 11.5), (5, 8.8), (11, 8.8), (13.5, 11.5), (13.5, 14.5)]))]

@glyph("users")
def _(): return [M(ngon(5.5, 5, 2.4), poly([(1, 13.5), (1, 11), (3, 8.8), (8, 8.8), (10, 11), (10, 13.5)])), D(ngon(11.2, 5.4, 2.1), poly([(10.5, 9), (13, 9), (15, 11), (15, 13.5), (11.5, 13.5)]))]

# ------------------------------------------------------------- devices
@glyph("terminal")
def _():
    return [M(frame(1.5, 2.5, 13, 11, 1.8, 2), pline([(4.5, 5.8), (7.2, 8.2), (4.5, 10.6)], 1.6, 0.2)), A(box(8.3, 10, 3.4, 1.6))]

@glyph("globe")
def _():
    return [M(ring(8, 8, 6.8, 5), ring(8, 8, 6.8, 5.3, sx=0.42), box(1.5, 7.2, 13, 1.6))]

@glyph("monitor")
def _(): return [M(frame(1.5, 2.2, 13, 8.8, 1.8, 1.5), box(5.5, 11, 5, 1.6), box(4, 12.6, 8, 1.6))]

@glyph("laptop")
def _(): return [M(frame(3, 2.5, 10, 7.5, 1.8, 1.2), poly([(1, 11.5), (15, 11.5), (14, 13.8), (2, 13.8)]))]

@glyph("keyboard")
def _():
    return [M(frame(1, 3.8, 14, 8.6, 1.6, 1.5)), D(box(3, 6, 1.5, 1.3), box(5.6, 6, 1.5, 1.3), box(8.2, 6, 1.5, 1.3), box(10.8, 6, 1.5, 1.3),
                                                    box(3, 8.3, 1.5, 1.3), box(5.6, 8.3, 1.5, 1.3), box(8.2, 8.3, 1.5, 1.3), box(10.8, 8.3, 1.5, 1.3))] if False else \
           [M(frame(1, 3.8, 14, 8.6, 1.6, 1.5), box(3.2, 6, 1.6, 1.4), box(6.2, 6, 1.6, 1.4), box(9.2, 6, 1.6, 1.4), box(5, 8.8, 6, 1.4))]

@glyph("mouse")
def _(): return [M(frame(4, 1.5, 8, 13, 1.8, 3)), A(box(7.2, 3.8, 1.6, 3))]

@glyph("disk")
def _(): return [M(frame(1.5, 4.5, 13, 7, 1.8, 1.5), box(3.5, 7.4, 4.5, 1.4)), A(box(10.8, 7.2, 1.8, 1.8))]

@glyph("ssd")
def _(): return [M(frame(2.5, 2, 11, 12, 1.8, 2), box(5, 4.5, 6, 1.4), box(5, 7.2, 3, 1.4)), A(box(9.2, 9.8, 1.8, 1.8))]

@glyph("usb")
def _():
    return [M(box(7.2, 3, 1.6, 10), tri((8, 0.8), (10.2, 4), (5.8, 4)), pline([(8, 9.5), (11.5, 9.5), (11.5, 6.8)], 1.5, 0.2),
              box(10.4, 4.8, 2.2, 2.2), pline([(8, 7.8), (4.6, 7.8), (4.6, 5.8)], 1.5, 0.2), ngon(4.6, 4.9, 1.5)), A(ngon(8, 13.6, 1.7))]

@glyph("optical")
def _(): return [M(ring(8, 8, 6.8, 4.9), ring(8, 8, 2.1, 0.8))]

@glyph("sdcard")
def _(): return [M(polyhole([(3, 1.5), (10.5, 1.5), (13, 4), (13, 14.5), (3, 14.5)], [(5, 3.5), (9.7, 3.5), (11, 4.9), (11, 12.5), (5, 12.5)]), box(5.2, 4.6, 1.2, 2.6), box(7.4, 4.6, 1.2, 2.6), box(9.6, 5.4, 1, 1.8))]

@glyph("camera")
def _(): return [M(frame(1.5, 4.5, 13, 8.8, 1.8, 1.5), box(5, 2.8, 3.4, 1.8), ring(8, 8.9, 2.9, 1.1))]

@glyph("phone")
def _(): return [M(frame(4.2, 1.5, 7.6, 13, 1.8, 1.5), box(7, 11.8, 2, 1))]

@glyph("printer2")
def _(): return G["print"]()

@glyph("mail")
def _(): return [M(frame(1.5, 3.2, 13, 9.6, 1.8, 1), pline([(2.8, 4.8), (8, 9), (13.2, 4.8)], 1.6, 0.2))]

@glyph("image")
def _(): return [M(frame(1.5, 2.2, 13, 11.6, 1.8, 1.5), poly([(3.6, 12), (7, 7.2), (9.6, 10.2), (11, 8.8), (12.4, 12)])), A(box(10, 4.4, 2, 2))]

@glyph("music")
def _():
    return [M(poly([(5, 2.6), (13, 1.4), (13, 4), (5, 5.2)]), bar(5.3, 3, 5.3, 12, 1.8, 0), bar(12.7, 2, 12.7, 11, 1.8, 0), ngon(3.7, 12.4, 2.3), ngon(11.1, 11.4, 2.3))]

@glyph("video")
def _(): return [M(frame(1.2, 3.6, 9.4, 8.8, 1.8, 1.4), poly([(11.6, 6.6), (14.8, 4.6), (14.8, 11.4), (11.6, 9.4)]))]

@glyph("archive")
def _(): return [M(frame(2.2, 1.8, 11.6, 12.4, 1.8, 2), box(7.1, 3.4, 1.8, 1.4), box(7.1, 6, 1.8, 1.4)), A(box(6.2, 9, 3.6, 3.2))]

@glyph("code")
def _(): return [M(pline([(5.5, 4), (1.6, 8), (5.5, 12)], 1.8, 0.3), pline([(10.5, 4), (14.4, 8), (10.5, 12)], 1.8, 0.3)), A(bar(9.2, 2.8, 6.8, 13.2, 1.5, 0))]

@glyph("shellcode")
def _(): return [M(pline([(2.5, 4.2), (6.8, 8), (2.5, 11.8)], 1.9, 0.3)), A(box(8.2, 10.6, 5.6, 1.9))]

@glyph("db")
def _():
    return [M(frame(2.2, 1.8, 11.6, 3.8, 1.5, 1), frame(2.2, 6.1, 11.6, 3.8, 1.5, 1), frame(2.2, 10.4, 11.6, 3.8, 1.5, 1)), A(box(10.4, 3.2, 1.6, 1), box(10.4, 7.5, 1.6, 1), box(10.4, 11.8, 1.6, 1))]

@glyph("wave")
def _(): return [M(pline([(1, 8), (4, 8), (5.8, 2.8), (8.2, 13.2), (10.2, 6), (11.8, 8), (15, 8)], 1.6, 0.2))]

@glyph("pulse")
def _(): return [M(frame(1.2, 2.4, 13.6, 11.2, 1.6, 1.5), pline([(3, 8.5), (5.5, 8.5), (6.8, 5.5), (8.8, 11), (10, 8.5), (13, 8.5)], 1.4, 0.2))]

@glyph("shield")
def _(): return [M(polyhole([(8, 1.3), (14, 3.4), (14, 8.6), (8, 14.8), (2, 8.6), (2, 3.4)], [(8, 3.5), (12, 4.9), (12, 8), (8, 12.1), (4, 8), (4, 4.9)])), A(box(7.1, 5.5, 1.8, 3.6))]

@glyph("bug")
def _():
    legs = [bar(1.4, 5.6, 5, 7.2, 1.4, 0), bar(1.2, 9.5, 5, 9.5, 1.4, 0), bar(1.8, 13.4, 5.2, 11.4, 1.4, 0)]
    legs += [bar(14.6 - (x - 1.4) + 1.4 - 1.4, y, 16 - x2, y2, 1.4, 0) for (x, y, x2, y2) in [(1.4, 5.6, 5, 7.2), (1.2, 9.5, 5, 9.5), (1.8, 13.4, 5.2, 11.4)]]
    return [M(ngon(8, 9.4, 3.7, 8, 22.5, 1, 1.15), ngon(8, 3.9, 2.1), legs), A(box(7.2, 7, 1.6, 6))]

@glyph("key")
def _():
    return [M(ring(5, 5, 3.6, 1.5), bar(7.3, 7.3, 13.8, 13.8, 2, 0.2), bar(11, 11, 13.2, 8.8, 1.6, 0), bar(13.3, 13.3, 15, 11.6, 1.5, 0))]

@glyph("radar")
def _(): return [M(ring(8, 8, 6.8, 5.2), ring(8, 8, 2.8, 1.5)), A(bar(8, 8, 12.8, 3.2, 1.7, 0.2))]

@glyph("crosshair")
def _():
    return [M(ring(8, 8, 5.6, 4), box(7.2, 0.8, 1.6, 4.6), box(7.2, 10.6, 1.6, 4.6), box(0.8, 7.2, 4.6, 1.6), box(10.6, 7.2, 4.6, 1.6)), A(ngon(8, 8, 1.7))]

@glyph("bolt")
def _(): return [M(poly([(9.6, 0.8), (3.2, 9), (7.4, 9), (6.2, 15.2), (12.8, 6.4), (8.6, 6.4)]))]

@glyph("chip")
def _():
    pins = []
    for p in (4.8, 7.2, 9.6):
        pins += [box(p, 1.2, 1.4, 2.6), box(p, 12.2, 1.4, 2.6), box(1.2, p, 2.6, 1.4), box(12.2, p, 2.6, 1.4)]
    return [M(frame(3.8, 3.8, 8.4, 8.4, 1.8, 1.2), pins), A(box(7, 7, 2, 2))]

@glyph("report")
def _(): return [M(polyhole([(2.5, 1.5), (13.5, 1.5), (13.5, 14.5), (2.5, 14.5)], [(4.4, 3.4), (11.6, 3.4), (11.6, 12.6), (4.4, 12.6)])), A(box(5.8, 8.8, 1.4, 2.4), box(8.3, 6.6, 1.4, 4.6), box(10.4, 5, 0.1, 0.1) if False else [])]

@glyph("mask")
def _(): return [M(polyhole([(1.5, 3.5), (14.5, 3.5), (14.5, 8), (11, 13.5), (5, 13.5), (1.5, 8)], [(3.5, 5.5), (12.5, 5.5), (12.5, 7.4), (10, 11.6), (6, 11.6), (3.5, 7.4)])), A(box(4.5, 6.3, 2.4, 1.2), box(9.1, 6.3, 2.4, 1.2))]

@glyph("calc")
def _(): return [M(frame(3, 1.5, 10, 13, 1.8, 1.5), box(4.8, 3.6, 6.4, 2.2)), D(box(4.8, 7.6, 1.8, 1.6), box(7.1, 7.6, 1.8, 1.6), box(9.4, 7.6, 1.8, 1.6), box(4.8, 10.2, 1.8, 1.6), box(7.1, 10.2, 1.8, 1.6)), A(box(9.4, 10.2, 1.8, 1.6))]

@glyph("palette")
def _(): return [M(frame(1.5, 2, 13, 12, 1.8, 3)), A(box(4.2, 4.5, 2, 2), box(8.2, 4.5, 2, 2)), D(box(4.2, 8.2, 2, 2), box(8.2, 8.2, 2, 2))]

@glyph("shot")
def _(): return G["brackets"]() + [A(box(6.2, 6.2, 3.6, 3.6))]

@glyph("update")
def _(): return G["refresh"]()

@glyph("rack")
def _(): return [M(frame(1.8, 1.8, 12.4, 4.2, 1.5, 1), frame(1.8, 6.6, 12.4, 4.2, 1.5, 1), frame(1.8, 11.4, 12.4, 3, 1.5, 1)), A(box(10.8, 3.2, 1.6, 1.2), box(10.8, 8, 1.6, 1.2))]

@glyph("netshare")
def _(): return [M(frame(5, 1.8, 6, 4.4, 1.5, 1), frame(1, 10, 6, 4.2, 1.5, 1), frame(9, 10, 6, 4.2, 1.5, 1), box(7.2, 6.2, 1.6, 2.2), box(3.6, 8.2, 8.8, 1.4), box(3.6, 8.2, 1.4, 2), box(11, 8.2, 1.4, 2))]

@glyph("link")
def _(): return [M(frame(1.2, 5.6, 7, 4.8, 1.6, 1.2), frame(7.8, 5.6, 7, 4.8, 1.6, 1.2))]

@glyph("logout")
def _(): return [M(polyhole([(2, 1.5), (9, 1.5), (9, 4.5), (7.2, 4.5), (7.2, 3.3), (3.8, 3.3), (3.8, 12.7), (7.2, 12.7), (7.2, 11.5), (9, 11.5), (9, 14.5), (2, 14.5)], [(3.8, 3.3), (3.8, 3.3), (3.8, 3.3)]) if False else poly([(2, 1.5), (9, 1.5), (9, 4.5), (7.2, 4.5), (7.2, 3.3), (3.8, 3.3), (3.8, 12.7), (7.2, 12.7), (7.2, 11.5), (9, 11.5), (9, 14.5), (2, 14.5)]), bar(7, 8, 13, 8, 1.8, 0), pline([(10.8, 5.2), (13.6, 8), (10.8, 10.8)], 1.8, 0.2))]

@glyph("J")  # placeholder JITTER glyph: swap with your real mark in start-here.svg
def _():
    return [M(poly([(5, 2), (13, 2), (13, 4.2), (10, 4.2), (10, 10.5), (7.4, 13.8), (3, 13.8), (3, 11.6), (6.8, 11.6), (7.4, 10.2), (7.4, 4.2), (5, 4.2)])), A(box(11, 6.2, 2.6, 2.6))]

@glyph("kali")  # menu glyph: chevron + dash in octagon
def _(): return [M(ring(8, 8, 7, 5.3), pline([(5.6, 5.8), (8.2, 8), (5.6, 10.2)], 1.6, 0.2)), A(box(8.9, 9.6, 2.6, 1.5))]

@glyph("question_s")
def _(): return G["question"]()

# multi-state helpers ------------------------------------------------
@glyph("fileplus")
def _(): return G["file"]() + [A(box(7.3, 7.5, 1.4, 4.6), box(5.7, 9.1, 4.6, 1.4))]
@glyph("folderplus")
def _(): return G["folder"]() + [A(box(7.3, 7.4, 1.4, 3.8), box(6.1, 8.6, 3.8, 1.4))]
@glyph("folderopen")
def _(): return [M(polyhole([(1.5, 3), (6.2, 3), (8, 5), (12.5, 5), (12.5, 6.8), (3.2, 6.8), (1.5, 13.5)], [(3.2, 5.1), (5.5, 5.1), (6.3, 6), (3.2, 6)]) if False else
                 poly([(1.5, 3), (6.2, 3), (8, 5), (12.5, 5), (12.5, 7), (4.2, 7), (1.5, 13.5)]), poly([(4.6, 8.4), (15, 8.4), (12.4, 13.5), (1.5, 13.5)]))]

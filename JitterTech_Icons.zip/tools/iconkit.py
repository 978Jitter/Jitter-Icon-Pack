"""JITTER icon kit: scene builders (plate / folder / document), keyword->glyph map, theme writer."""
import os, re, hashlib
from jitlib import *
from glyphs import G

SYMCOL = {"m": "#bebebe", "a": "#bebebe", "d": "#bebebe", "w": "#bebebe"}

# ---------------------------------------------------------------- builders
def _brackets(sc, small=False):
    br = [[(4, 24), (4, 13), (13, 4), (24, 4)], [(40, 4), (51, 4), (60, 13), (60, 24)],
          [(60, 40), (60, 51), (51, 60), (40, 60)], [(24, 60), (13, 60), (4, 51), (4, 40)]]
    cols = [STEEL, STEEL, STEEL, RED]
    for pts, col in zip(br, cols):
        if small and col == STEEL: continue
        sc.path(pline(pts, 2.6, 0.3), fill=col)

def _hatch(sc, clip, y0, y1, x0=-20, x1=70, op=0.07):
    h = y1 - y0
    for i in range(x0, x1, 8):
        sc.path([bar(i, y1, i + h, y0, 1.6, 0)], fill=SILVER, op=op, clip=clip)

def draw_glyph(sc, parts, scale, ox, oy, shadow=True, colors=None):
    if shadow:
        sc.parts(parts, scale, ox + 1.1, oy + 1.1, colors={k: OBSIDIAN for k in ROLE}, op=0.55)
    sc.parts(parts, scale, ox, oy, colors=colors)

def plate(parts, small=False, danger=False, gscale=None):
    sc = Scene(64)
    c = 7 if small else 9
    outer = box(4, 4, 56, 56, c)
    grad = (CRIMSON, BURGUNDY) if danger else (GR_LT, GR_DK)
    sc.path([outer], grad=grad, stroke=GUNMETAL, sw=2)
    if not small:
        clip = [poly([(13, 4), (51, 4), (60, 13), (60, 17), (4, 17), (4, 13)])]
        _hatch(sc, clip, 4, 21)
    _brackets(sc, small)
    s = gscale or (2.7 if small else 2.25)
    off = 32 - 8 * s
    draw_glyph(sc, parts, s, off, off, shadow=not small)
    return sc

def folder(parts=None, open_=False, small=False, accent=True):
    sc = Scene(64)
    back = poly([(10, 10), (24, 10), (30, 17), (54, 17), (60, 23), (60, 48), (54, 54), (10, 54), (4, 48), (4, 16)])
    sc.path([back], grad=("#262B30", GR_DK), stroke=GUNMETAL, sw=2)
    if not small:
        tab = [poly([(4, 16), (10, 10), (24, 10), (30, 17), (4, 17)])]
        _hatch(sc, tab, 10, 17, -10, 40, 0.1)
    sc.path([box(11, 12.2, 7, 2)], fill=RED)
    if open_:
        front = poly([(10, 28), (62, 28), (55, 54), (10, 54), (4, 48), (4, 34)])
    else:
        front = poly([(4, 26), (60, 26), (60, 48), (54, 54), (10, 54), (4, 48)])
    sc.path([front], grad=("#3A4047", "#20252A"), stroke=STEEL, sw=1.6, sop=0.9)
    if not small:
        sc.path(pline([(4, 40), (4, 48), (10, 54), (18, 54)], 2.6, 0.3), fill=RED)
        sc.path(pline([(60, 40), (60, 48), (54, 54), (46, 54)], 2.6, 0.3), fill=STEEL)
    if parts:
        s = 1.5 if not small else 1.7
        ox = 32 - 8 * s + (2 if open_ else 0); oy = 40 - 8 * s
        draw_glyph(sc, parts, s, ox, oy, shadow=not small)
    return sc

BANDS = {"gun": GUNMETAL, "red": RED, "crim": CRIMSON, "burg": BURGUNDY, "steel": STEEL}

def document(parts, band="gun", small=False):
    sc = Scene(64)
    page = poly([(12, 4), (40, 4), (54, 18), (54, 56), (50, 60), (16, 60), (12, 56)])
    sc.path([page], grad=(GR_LT, GR_DK), stroke=GUNMETAL, sw=2)
    sc.path([poly([(40, 4), (54, 18), (40, 18)])], fill=GUNMETAL, stroke=STEEL, sw=1.4)
    bp = poly([(12, 49), (54, 49), (54, 56), (50, 60), (16, 60), (12, 56)])
    sc.path([bp], fill=BANDS[band])
    if not small:
        _hatch(sc, [bp], 49, 60, -20, 70, 0.12)
        sc.path(pline([(12, 18), (12, 4), (24, 4)], 2.6, 0.3), fill=STEEL)
    sc.path([box(12, 49, 42, 1.2)], fill=OBSIDIAN, op=0.6)
    s = 1.75 if not small else 2.0
    ox = 33 - 8 * s; oy = 33 - 8 * s
    draw_glyph(sc, parts, s, ox, oy, shadow=not small)
    return sc

# ---------------------------------------------------------------- keyword map
KEYMAP = [
    (("nmap", "zenmap", "masscan", "unicornscan", "netdiscover", "arp-scan", "recon", "dmitry", "amass", "theharvester", "maltego", "spiderfoot", "fierce", "dnsenum", "dnsrecon", "enum4linux", "smbmap", "information", "gathering", "osint", "sherlock", "shodan", "radar"), "radar"),
    (("wireshark", "tshark", "tcpdump", "ettercap", "bettercap", "responder", "sniffing", "spoofing", "mitm", "dsniff", "macchanger", "yersinia", "netsniff", "termshark", "pcap", "sniff", "spoof"), "wave"),
    (("metasploit", "msfconsole", "msfvenom", "msf", "exploit", "exploitation", "searchsploit", "armitage", "routersploit", "commix", "beef", "shellcode", "crosshair"), "crosshair"),
    (("burpsuite", "burp", "zaproxy", "zap", "owasp", "sqlmap", "nikto", "wpscan", "dirb", "dirbuster", "gobuster", "ffuf", "wfuzz", "whatweb", "skipfish", "w3af", "webapp", "web", "joomscan", "xsser", "davtest", "cadaver", "wapiti"), "globe"),
    (("sqlite", "mysql", "mssql", "oracle", "database", "postgres", "mongo", "redis", "dbeaver", "sqlninja", "sqlmap-db"), "db"),
    (("aircrack", "airodump", "wifite", "kismet", "reaver", "bully", "fern", "wireless", "wifi", "wlan", "mdk", "pixie", "cowpatty", "hostapd", "eaphammer", "bluetooth", "btscanner", "bluez", "ubertooth"), "wifi"),
    (("john", "johnny", "hashcat", "hydra", "medusa", "ncrack", "crunch", "cewl", "password", "passwords", "crack", "ophcrack", "patator", "hash", "rainbow", "cupp", "brutespray", "mimikatz", "crackmapexec", "netexec", "wordlist", "wordlists"), "key"),
    (("ghidra", "radare", "radare2", "r2", "cutter", "gdb", "edb", "ida", "reverse", "engineering", "objdump", "ropper", "binwalk", "apktool", "jadx", "dex2jar", "frida", "pwndbg", "gef", "capstone", "yara", "hexedit", "bless", "ghex", "rizin", "ollydbg"), "code"),
    (("autopsy", "volatility", "foremost", "scalpel", "sleuthkit", "forensic", "forensics", "bulk_extractor", "guymager", "dc3dd", "extundelete", "photorec", "testdisk", "chkrootkit", "rkhunter", "exiftool", "steghide", "stegseek", "outguess", "xplico"), "search"),
    (("openvas", "gvm", "nessus", "lynis", "legion", "vulnerability", "vulnerabilities", "nuclei", "sslscan", "sslyze", "testssl", "cve", "bug", "vuln", "openscap"), "bug"),
    (("setoolkit", "social", "phishing", "gophish", "king-phisher", "evilginx", "blackeye", "wifiphisher", "engineering-social"), "mask"),
    (("hping", "hping3", "slowloris", "stress", "testing", "dos", "flood", "siege", "goldeneye", "hulk"), "bolt"),
    (("hardware", "hacking", "arduino", "openocd", "flashrom", "minicom", "serial", "firmware", "avrdude", "sdr", "gqrx", "rtl", "hackrf", "proxmark", "gnuradio", "jtag", "uart"), "chip"),
    (("report", "reporting", "dradis", "faraday", "cherrytree", "pipal", "keepnote", "casefile", "magictree", "notes"), "report"),
    (("powershell", "empire", "weevely", "evil-winrm", "netcat", "socat", "chisel", "ligolo", "sliver", "covenant", "pwncat", "proxychains", "tunnel", "ssh", "post-exploitation", "postexploitation", "backdoor", "persistence", "bloodhound", "impacket", "shell", "terminal", "xterm", "tmux", "konsole", "console"), "terminal"),
    (("openssl", "gpg", "gnupg", "cert", "ssl", "encrypt", "crypt", "keepass", "veracrypt", "tor", "vpn", "openvpn", "wireguard", "firewall", "ufw", "iptables", "nftables", "shield", "security"), "shield"),
    (("docker", "virtualbox", "vmware", "qemu", "kvm", "container", "archive", "zip", "tar", "7z", "file-roller", "xarchiver", "engrampa", "package"), "archive"),
    (("vscode", "code", "geany", "sublime", "vim", "emacs", "nano", "mousepad", "editor", "python", "java", "ruby", "perl", "rust", "node", "php", "script", "pycharm", "gedit", "development", "ide"), "code"),
    (("chrome", "chromium", "firefox", "firefox-esr", "browser", "epiphany", "midori", "lynx", "brave", "opera", "internet", "web-browser"), "globe"),
    (("mail", "thunderbird", "evolution", "claws", "mutt", "email"), "mail"),
    (("monitor", "htop", "taskmanager", "task", "process", "perf", "nmon", "glances", "btop", "iotop", "sensors", "activity", "resource"), "pulse"),
    (("network", "dhcp", "dns", "nic", "route", "ping", "traceroute", "mtr", "whois", "netstat", "ethernet", "networkmanager", "nm-connection-editor", "nm-applet"), "ethernet"),
    (("disk", "partition", "gparted", "mount", "storage", "hdd", "smart", "format", "backup", "drive"), "disk"),
    (("video", "vlc", "mpv", "player", "movie", "obs", "ffmpeg", "kdenlive", "totem", "cheese", "multimedia"), "video"),
    (("music", "audio", "sound", "pavucontrol", "audacity", "spotify", "rhythmbox", "audacious", "volume"), "music"),
    (("image", "photo", "picture", "gimp", "inkscape", "krita", "ristretto", "eog", "viewer", "gallery", "shotwell", "imagemagick", "graphics"), "image"),
    (("screenshot", "screenshooter", "flameshot"), "shot"),
    (("pdf", "document", "office", "libreoffice", "writer", "impress", "evince", "okular", "zathura", "atril", "doc", "wps"), "filelines"),
    (("calculator", "calc", "galculator", "qalculate"), "calc"),
    (("keyring", "seahorse", "bitwarden", "pass", "ssh-keygen", "keygen"), "key"),
    (("user", "users", "account", "accounts", "login", "contacts", "people"), "user"),
    (("clock", "time", "date", "calendar", "alarm", "timer", "schedule", "cron", "orage"), "clock"),
    (("search", "find", "locate", "recoll", "catfish", "appfinder", "grep", "finder"), "search"),
    (("download", "wget", "curl", "aria2", "transmission", "qbittorrent", "deluge", "torrent", "git", "clone"), "download"),
    (("update", "upgrade", "apt", "synaptic", "software", "dpkg", "installer", "install"), "update"),
    (("help", "about", "manual", "docs", "faq", "man", "yelp"), "question"),
    (("power", "shutdown", "poweroff", "halt", "reboot", "logout", "session"), "power"),
    (("lock", "screensaver", "xscreensaver", "light-locker"), "lock"),
    (("camera", "webcam"), "camera"),
    (("keyboard", "xkb", "input", "onboard"), "keyboard"),
    (("mouse", "pointer", "touchpad", "cursor"), "mouse"),
    (("display", "screen", "xrandr", "arandr", "resolution", "wallpaper", "desktop", "appearance", "theme", "fonts"), "monitor"),
    (("settings", "config", "configuration", "setup", "manager", "preferences", "tweak", "admin", "services", "service", "system", "extra"), "gear"),
    (("kali", "menu", "whiskermenu", "whisker", "start-here", "distributor"), "kali"),
]
FALLBACK = ["radar", "crosshair", "chip", "code", "pulse", "gear", "shield", "bolt", "rack", "link", "terminal", "wave"]

def guess_glyph(name):
    n = name.lower()
    n = re.sub(r"^(kali-|org\.[a-z0-9_]+\.|com\.[a-z0-9_]+\.|application-x-|x-)", "", n)
    toks = [t for t in re.split(r"[-_.\s0-9]+", n) if t]
    for words, g in KEYMAP:
        for w in words:
            if w in toks or w == n or (len(w) >= 5 and w in n):
                return g
    return FALLBACK[int(hashlib.md5(n.encode()).hexdigest(), 16) % len(FALLBACK)]

# ---------------------------------------------------------------- writer
CTX = {"apps": "Applications", "places": "Places", "devices": "Devices", "mimetypes": "MimeTypes",
       "status": "Status", "actions": "Actions", "categories": "Categories", "emblems": "Emblems"}

class Theme:
    def __init__(self, root):
        self.root = root; self.dirs = {}; self.names = {"color": set(), "symbolic": set()}

    def _w(self, sub, name, text):
        d = os.path.join(self.root, sub); os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, name + ".svg"), "w") as f: f.write(text)

    @staticmethod
    def _junk(name):
        return name.endswith("-no") or name.endswith("-app") or name.endswith("-status")

    def color(self, ctx, name, large, small=None):
        if self._junk(name): return
        self._w(f"scalable/{ctx}", name, large.svg()); self.dirs[f"scalable/{ctx}"] = ("scalable", ctx)
        if small is not None:
            self._w(f"small/{ctx}", name, small.svg()); self.dirs[f"small/{ctx}"] = ("small", ctx)
        self.names["color"].add((ctx, name))

    def sym(self, ctx, name, parts):
        if self._junk(name): return
        sc = Scene(16); sc.parts(parts, colors=SYMCOL)
        self._w(f"symbolic/{ctx}", name + "-symbolic", sc.svg()); self.dirs[f"symbolic/{ctx}"] = ("symbolic", ctx)
        self.names["symbolic"].add((ctx, name))

    def index(self, name="JITTER", inherits="Adwaita,hicolor"):
        order = sorted(self.dirs, key=lambda d: ({"small": 0, "scalable": 1, "symbolic": 2}[self.dirs[d][0]], d))
        out = ["[Icon Theme]", f"Name={name}", "Comment=Industrial gunmetal / blood crimson HUD icons",
               f"Inherits={inherits}", "Directories=" + ",".join(order), ""]
        for d in order:
            kind, ctx = self.dirs[d]
            out.append(f"[{d}]")
            if kind == "small":
                out += ["Size=16", "MinSize=8", "MaxSize=22", "Type=Scalable"]
            elif kind == "scalable":
                out += ["Size=64", "MinSize=24", "MaxSize=512", "Type=Scalable"]
            else:
                out += ["Size=16", "MinSize=8", "MaxSize=512", "Type=Scalable"]
            out += [f"Context={CTX[ctx]}", ""]
        with open(os.path.join(self.root, "index.theme"), "w") as f: f.write("\n".join(out))

# convenience: make an app-style plate icon for any (name, glyph)
def add_plate(theme, ctx, name, glyph, **kw):
    parts = G[glyph](**kw) if kw else G[glyph]()
    theme.color(ctx, name, plate(parts), plate(parts, small=True))

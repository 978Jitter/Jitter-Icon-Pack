"""JITTER icon library — primitives, scene graph, SVG writer and exact PIL preview.
All geometry is polygonal (octagons instead of circles: chamfered, mechanical).
"""
import math

# ---------------------------------------------------------------- palette
OBSIDIAN = "#08090B"; CRIMSON = "#65121C"; RED = "#A6192E"; BURGUNDY = "#35151C"
GRAPHITE = "#24282D"; GUNMETAL = "#454B52"; STEEL = "#899097"; SILVER = "#D5D8DC"; WHITE = "#F2F0ED"
GR_LT = "#2E3338"; GR_DK = "#171A1E"; RED_LT = "#C21F38"
ROLE = {"m": SILVER, "a": RED, "d": STEEL, "w": WHITE}

# ---------------------------------------------------------------- geometry
def area(p):
    return sum(p[i][0] * p[(i + 1) % len(p)][1] - p[(i + 1) % len(p)][0] * p[i][1] for i in range(len(p))) / 2

def cw(p):   # filled subpath (positive area in y-down space)
    return list(p) if area(p) > 0 else list(reversed(p))

def ccw(p):  # hole subpath
    return list(p) if area(p) < 0 else list(reversed(p))

def box(x, y, w, h, c=0):
    if c <= 0:
        return cw([(x, y), (x + w, y), (x + w, y + h), (x, y + h)])
    return cw([(x + c, y), (x + w - c, y), (x + w, y + c), (x + w, y + h - c),
               (x + w - c, y + h), (x + c, y + h), (x, y + h - c), (x, y + c)])

def hole(x, y, w, h, c=0):
    return ccw(box(x, y, w, h, c))

def frame(x, y, w, h, t=2, c=0):
    ic = max(c - t * 0.41, 0)
    return [box(x, y, w, h, c), hole(x + t, y + t, w - 2 * t, h - 2 * t, ic)]

def poly(pts):
    return cw(pts)

def polyhole(outer, inner):
    return [cw(outer), ccw(inner)]

def ngon(cx, cy, r, n=8, start=22.5, sx=1, sy=1):
    return cw([(cx + sx * r * math.cos(math.radians(start + 360 * i / n)),
                cy + sy * r * math.sin(math.radians(start + 360 * i / n))) for i in range(n)])

def ring(cx, cy, ro, ri, n=8, sx=1, sy=1):
    return [ngon(cx, cy, ro, n, sx=sx, sy=sy), ccw(ngon(cx, cy, ri, n, sx=sx, sy=sy))]

def ngon_pts(cx, cy, r, n=8, start=22.5):
    return [(cx + r * math.cos(math.radians(start + 360 * i / n)),
             cy + r * math.sin(math.radians(start + 360 * i / n))) for i in range(n)]

def bar(x1, y1, x2, y2, t=2, ext=0):
    dx, dy = x2 - x1, y2 - y1
    L = math.hypot(dx, dy) or 1
    ux, uy = dx / L, dy / L
    x1 -= ux * ext; y1 -= uy * ext; x2 += ux * ext; y2 += uy * ext
    nx, ny = -uy * t / 2, ux * t / 2
    return cw([(x1 + nx, y1 + ny), (x2 + nx, y2 + ny), (x2 - nx, y2 - ny), (x1 - nx, y1 - ny)])

def pline(pts, t=2, ext=None):
    e = t / 2 if ext is None else ext
    return [bar(*pts[i], *pts[i + 1], t, e) for i in range(len(pts) - 1)]

def tri(a, b, c):
    return cw([a, b, c])

# transforms on a list of subpaths
def xf(subs, sx=1, sy=1, dx=0, dy=0):
    return [[(x * sx + dx, y * sy + dy) for x, y in s] for s in subs]

def rot(subs, deg, cx=8, cy=8):
    a = math.radians(deg); ca, sa = math.cos(a), math.sin(a)
    return [[(cx + (x - cx) * ca - (y - cy) * sa, cy + (x - cx) * sa + (y - cy) * ca) for x, y in s] for s in subs]

def flat(*items):
    """flatten nested lists of subpaths: each subpath is a list of (x,y) tuples"""
    out = []
    def rec(it):
        if it and isinstance(it[0], tuple):
            out.append(it)
        else:
            for i in it: rec(i)
    for i in items: rec(i)
    return out

# parts: list of (role, [subpaths])
def M(*s): return ("m", flat(*s))
def A(*s): return ("a", flat(*s))
def D(*s): return ("d", flat(*s))

def parts_xf(parts, **kw):
    return [(r, xf(s, **kw)) for r, s in parts]

def parts_rot(parts, deg, cx=8, cy=8):
    return [(r, rot(s, deg, cx, cy)) for r, s in parts]

def parts_mirror(parts, cx=8):
    return [(r, [list(reversed([(2 * cx - x, y) for x, y in s])) for s in subs]) for r, subs in parts]

# ---------------------------------------------------------------- scene
def f2(v):
    s = f"{v:.2f}".rstrip("0").rstrip(".")
    return s if s not in ("-0", "") else "0"

def hex2rgb(h):
    h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

class Scene:
    def __init__(self, vb):
        self.vb = vb; self.items = []; self.defs = []; self._id = 0

    def path(self, subs, fill=None, grad=None, stroke=None, sw=0, op=1.0, clip=None, sop=1.0):
        self.items.append(dict(subs=flat(subs), fill=fill, grad=grad, stroke=stroke, sw=sw, op=op, clip=clip, sop=sop))

    def parts(self, parts, scale=1.0, dx=0, dy=0, colors=None, op=1.0):
        colors = colors or ROLE
        for role, subs in parts:
            self.path(xf(subs, scale, scale, dx, dy), fill=colors[role], op=op)

    # --- SVG
    def _d(self, subs):
        return "".join("M" + "L".join(f"{f2(x)} {f2(y)}" for x, y in s) + "Z" for s in subs)

    def svg(self):
        out = []; defs = []; gid = 0; cid = 0
        for it in self.items:
            attrs = []
            if it["grad"]:
                gid += 1
                defs.append(f'<linearGradient id="g{gid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{it["grad"][0]}"/><stop offset="1" stop-color="{it["grad"][1]}"/></linearGradient>')
                attrs.append(f'fill="url(#g{gid})"')
            elif it["fill"]:
                attrs.append(f'fill="{it["fill"]}"')
            else:
                attrs.append('fill="none"')
            if it["op"] != 1: attrs.append(f'fill-opacity="{f2(it["op"])}"')
            if it["stroke"]:
                attrs.append(f'stroke="{it["stroke"]}" stroke-width="{f2(it["sw"])}" stroke-linejoin="miter"')
                if it["sop"] != 1: attrs.append(f'stroke-opacity="{f2(it["sop"])}"')
            if it["clip"]:
                cid += 1
                defs.append(f'<clipPath id="c{cid}"><path d="{self._d(flat(it["clip"]))}"/></clipPath>')
                attrs.append(f'clip-path="url(#c{cid})"')
            out.append(f'<path d="{self._d(it["subs"])}" {" ".join(attrs)}/>')
        d = f"<defs>{''.join(defs)}</defs>" if defs else ""
        v = f2(self.vb)
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{v}" height="{v}" viewBox="0 0 {v} {v}">'
                f'{d}{"".join(out)}</svg>\n')

    # --- exact preview renderer (nonzero winding, same maths as SVG)
    def render(self, px, bg=None):
        import numpy as np
        from PIL import Image, ImageDraw
        ss = 4; S = px * ss; k = S / self.vb
        rgb = np.zeros((S, S, 3)); alpha = np.zeros((S, S))
        yy = (np.arange(S) + 0.5)[:, None] / k

        def mask_of(subs):
            w = np.zeros((S, S), dtype=np.int16)
            for s in subs:
                if len(s) < 3: continue
                m = Image.new("L", (S, S), 0)
                ImageDraw.Draw(m).polygon([(x * k, y * k) for x, y in s], fill=1)
                w += np.array(m, dtype=np.int16) * (1 if area(s) > 0 else -1)
            return w != 0

        for it in self.items:
            subs = it["subs"]
            if not subs: continue
            clipm = mask_of(flat(it["clip"])) if it["clip"] else None
            if it["fill"] or it["grad"]:
                cov = mask_of(subs)
                if clipm is not None: cov &= clipm
                if it["grad"]:
                    ys = [y for s in subs for _, y in s]; y0, y1 = min(ys), max(ys)
                    t = np.clip((yy - y0) / max(y1 - y0, 1e-6), 0, 1)
                    c0 = np.array(hex2rgb(it["grad"][0])); c1 = np.array(hex2rgb(it["grad"][1]))
                    col = c0[None, None, :] * (1 - t[..., None]) + c1[None, None, :] * t[..., None]
                    col = np.broadcast_to(col, (S, S, 3))
                else:
                    col = np.array(hex2rgb(it["fill"]), dtype=float)[None, None, :]
                a = cov * it["op"]
                rgb = col * a[..., None] + rgb * (1 - a[..., None]); alpha = a + alpha * (1 - a)
            if it["stroke"]:
                m = Image.new("L", (S, S), 0); dr = ImageDraw.Draw(m)
                for s in subs:
                    pts = [(x * k, y * k) for x, y in s] + [(s[0][0] * k, s[0][1] * k)]
                    dr.line(pts, fill=1, width=max(1, int(it["sw"] * k)), joint="curve")
                cov = np.array(m, dtype=bool)
                if clipm is not None: cov &= clipm
                col = np.array(hex2rgb(it["stroke"]), dtype=float)[None, None, :]
                a = cov * it["sop"]
                rgb = col * a[..., None] + rgb * (1 - a[..., None]); alpha = a + alpha * (1 - a)
        # box downsample
        rgb = rgb.reshape(px, ss, px, ss, 3).mean((1, 3)); alpha = alpha.reshape(px, ss, px, ss).mean((1, 3))
        out = np.zeros((px, px, 4), dtype=np.uint8)
        nz = alpha > 1e-6
        out[..., :3][nz] = np.clip(rgb[nz] / alpha[nz][:, None], 0, 255)
        out[..., 3] = np.clip(alpha * 255, 0, 255)
        im = Image.fromarray(out, "RGBA")
        if bg:
            base = Image.new("RGBA", (px, px), bg); base.alpha_composite(im); return base
        return im

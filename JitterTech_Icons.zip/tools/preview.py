import sys; sys.path.insert(0,'.')
from jitlib import *; from glyphs import G; from iconkit import *
from PIL import Image, ImageDraw
BG=(30,33,38,255); CELL=104
def sheet(rows, path, px=80):
    W=max(len(r) for r in rows)*CELL; H=len(rows)*CELL
    sh=Image.new("RGBA",(W,H),BG)
    for y,row in enumerate(rows):
        for x,(label,sc) in enumerate(row):
            im=sc.render(px); sh.alpha_composite(im,(x*CELL+12,y*CELL+4))
            ImageDraw.Draw(sh).text((x*CELL+6,y*CELL+86),label[:15],fill=(137,144,151,255))
    sh.save(path)
P=lambda g,**k:G[g](**k)
apps=[(g,plate(P(g))) for g in ["terminal","folder","globe","edit","gear","palette","monitor","power","pulse","calc","shot","search","J"]]
kali=[(g,plate(P(g))) for g in ["radar","bug","globe","db","key","wifi","code","crosshair","wave","terminal","search","report","mask","chip","bolt","kali"]]
fold=[("folder",folder()),("open",folder(open_=True))]+[(g,folder(P(g))) for g in ["home","monitor","filelines","download","music","image","video","trash","trashfull","netshare","lock"]]
docs=[(g,document(P(g),b)) for g,b in [("filelines","gun"),("shellcode","burg"),("code","burg"),("filelines","crim"),("archive","steel"),("wave","red"),("gear","red"),("image","gun"),("music","gun"),("video","gun"),("db","burg"),("shield","crim")]]
dlg=[("info",plate(P("sign_info"),gscale=2.3)),("warn",plate(P("sign_warn"),gscale=2.3)),("error",plate(P("sign_err"),danger=True,gscale=2.3)),("question",plate(P("sign_q"),gscale=2.3)),
     ("bat",plate(P("battery",level=80))),("wifi",plate(P("wifi",level=3))),("usb",plate(P("usb"))),("disk",plate(P("disk"))),("camera",plate(P("camera"))),("mic",plate(P("mic")))]
sheet([apps,kali,fold,docs,dlg],'/tmp/prev_color.png')
# small variants at real sizes
sm=Image.new("RGBA",(CELL*13,100),BG)
for i,g in enumerate(["terminal","folder","globe","edit","gear","palette","monitor","power","pulse","calc","shot","search","J"]):
    sc=plate(P(g),small=True)
    for j,px in enumerate((16,24,32,48)):
        pass
    x=i*CELL
    for px,yy in ((16,8),(24,30),(32,60)): sm.alpha_composite(sc.render(px),(x+8,yy)) if px<=32 else None
    sm.alpha_composite(sc.render(48),(x+44,26))
sm=sm.resize((sm.width*2,sm.height*2),Image.NEAREST); sm.save('/tmp/prev_small.png')
# symbolic strip
names=["wifi","battery","volume","bluetooth","bell","power","lock","user","search","gear","menu","dots","refresh","x","check","plus","minus","home","folder","trash","copy","paste","undo","play","pause","download","terminal","mail","image","bookmark","edit","save"]
strip=Image.new("RGBA",(len(names)*40,48),(8,9,11,255))
for i,n in enumerate(names):
    sc=Scene(16); kw={}
    sc.parts(P(n),colors={k:"#D5D8DC" for k in ROLE}); strip.alpha_composite(sc.render(32),(i*40+4,8))
strip=strip.resize((strip.width*1,strip.height*1)); strip.save('/tmp/prev_sym.png')

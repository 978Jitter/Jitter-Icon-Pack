#!/usr/bin/env bash
rm -rf "$HOME/.local/share/icons/JITTER" "$HOME/.local/share/jitter-icons"
xfconf-query -c xsettings -p /Net/IconThemeName -s "Adwaita" 2>/dev/null
xfce4-panel -r >/dev/null 2>&1 &
echo "JITTER icons removed (icon theme set back to Adwaita; change it in Settings > Appearance > Icons)."
